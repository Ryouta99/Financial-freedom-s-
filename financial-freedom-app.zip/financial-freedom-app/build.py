#!/usr/bin/env python3
"""Build Financial Freedom from src/ into every target.

Usage:  python3 build.py

The app is plain HTML/CSS/JS with no dependencies. Source files in src/ are
joined in the order listed below and written as single-file pages:

  www/index.html                 Android APK (Capacitor) and installable web app
  desktop/index.html             Windows desktop app (Electron)
  dist/financial-freedom.html    one-file version to open directly in a browser
  dist/claude-artifact.html      version published inside Claude

All JavaScript files share one scope (they are wrapped together in a single
function), so they must be listed in dependency order: a file may only use, at
load time, names defined in files listed before it. Functions called later at
run time can live anywhere.
"""
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"

STYLES = [
    "tokens.css",       # colours, fonts, light/dark theme
    "base.css",         # reset, body, buttons
    "layout.css",       # header, sections, bottom navigation
    "components.css",   # hero, account cards, lists, filters, sheet
    "views.css",        # statistics and savings screens
    "category.css",     # expense breakdown per category
    "scan.css",         # receipt scanning, file buttons, toast
    "motion.css",       # animations (must stay last)
]

SCRIPTS = [
    "core/icons.js",          # SVG icon paths + ic()
    "core/config.js",         # categories, account & savings types
    "core/format.js",         # money/date formatting, parsing
    "core/state.js",          # app state S + data queries
    "core/storage.js",        # save/load (Claude cloud or local), render scheduling
    "ui/render.js",           # render(), count-up, month bar
    "views/home.js",          # Beranda
    "views/transactions.js",  # Riwayat
    "views/stats.js",         # Statistik
    "views/assets.js",        # Rekening & Tabungan
    "ui/sheet.js",            # bottom sheet + toast
    "sheets/transaction.js",  # add/edit transaction, transfer
    "sheets/account.js",      # account form + detail
    "sheets/savings.js",      # savings form + detail
    "sheets/add-menu.js",     # + menu
    "features/category.js",   # expense breakdown & budget per category
    "features/scan.js",       # receipt photo picking + preview
    "features/ocr.js",        # on-device receipt reading (outside Claude)
    "features/scan-claude.js",# receipt reading by Claude (inside Claude)
    "sheets/settings.js",     # settings sheet
    "features/demo.js",       # sample data
    "app/actions.js",         # button actions (data-act)
    "app/events.js",          # click/input/change/submit listeners
    "features/files.js",      # CSV export, backup, restore
    "features/native.js",     # Android status bar + back button
    "main.js",                # init() and start
]


def read(rel):
    return (SRC / rel).read_text(encoding="utf-8")


def bundle(extra_styles=()):
    css = "".join(read("styles/" + f) for f in list(STYLES) + list(extra_styles))
    js = "".join(read("js/" + f) for f in SCRIPTS)
    return (
        read("shell/head.html")
        + "<style>\n" + css + "</style>\n\n"
        + read("shell/body.html")
        + "\n<script>\n(() => {\n\"use strict\";\n" + js + "})();\n</script>\n"
    )


def write(rel, text):
    path = ROOT / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    print(f"  {rel:34s} {len(text.encode()) / 1024:6.1f} KB")


def main():
    print("Building Financial Freedom")
    page = bundle()
    write("dist/claude-artifact.html", page)
    write("dist/financial-freedom.html", read("shell/standalone-head.html") + page + "</body>\n</html>\n")
    write("www/index.html", read("shell/pwa-head.html") + page + read("shell/pwa-tail.html"))
    desktop = bundle(extra_styles=["desktop.css"])
    write("desktop/index.html", read("shell/pwa-head.html") + desktop + read("shell/pwa-tail.html"))
    for icon in (ROOT / "www" / "icons").glob("*.png"):
        (ROOT / "desktop" / "icons").mkdir(exist_ok=True)
        shutil.copy(icon, ROOT / "desktop" / "icons" / icon.name)
    shutil.copy(ROOT / "www" / "manifest.webmanifest", ROOT / "desktop" / "manifest.webmanifest")
    print("Done.")


if __name__ == "__main__":
    main()
