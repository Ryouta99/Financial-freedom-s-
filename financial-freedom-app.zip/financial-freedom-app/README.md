# Financial Freedom

Aplikasi catatan keuangan pribadi: rekening, pemasukan, pengeluaran, transfer, pos anggaran per kategori, tabungan & emas, scan struk, grafik, serta cadangkan/pulihkan data.

Satu kode sumber dipakai untuk semua versi:

| Versi | Hasil build | Dibuat oleh |
|---|---|---|
| Android (APK) | `www/index.html` | GitHub Actions: **Build APK Android** |
| Web yang bisa dipasang (PWA) | `www/index.html` | GitHub Actions: **Terbitkan versi web** |
| Desktop Windows | `desktop/index.html` | GitHub Actions: **Build aplikasi desktop Windows** |
| File HTML tunggal | `dist/financial-freedom.html` | `python3 build.py` |
| Versi di Claude | `dist/claude-artifact.html` | `python3 build.py` |

---

## Bagian 1: Memakai aplikasi

### Ambil APK Android
1. Buka tab **Actions** di GitHub, lalu pilih **Build APK Android**.
2. Buka build terbaru yang bertanda centang hijau. Di bagian **Artifacts**, unduh **financial-freedom-apk**.
3. Ekstrak ZIP-nya di HP, lalu pasang **financial-freedom.apk**. Kalau diminta, izinkan pemasangan dari sumber tidak dikenal.

Setiap APK ditandatangani dengan kunci dari folder `keystore/`. Karena kuncinya selalu sama, versi baru bisa langsung dipasang di atas versi lama tanpa kehilangan data. **Jangan hapus folder `keystore/`.**

### Ambil aplikasi desktop Windows
1. Buka tab **Actions**, pilih **Build aplikasi desktop Windows**, lalu unduh **financial-freedom-windows** dari build terbaru.
2. Ekstrak ZIP-nya ke folder tetap, misalnya Documents, lalu jalankan **Buat Shortcut.bat**.
3. Saat pertama kali dibuka, Windows mungkin menampilkan peringatan. Pilih **More info → Run anyway**.

### Versi web (opsional)
1. Buka **Settings → Pages**, lalu ubah *Source* ke **GitHub Actions**.
2. Buka `https://NAMA-AKUN.github.io/NAMA-REPOSITORY/` di Chrome, lalu tekan **Pasang**.

### Data
- Data tersimpan di perangkat masing-masing: HP, komputer, atau browser.
- Untuk memindahkan data, pakai **Pengaturan → Cadangkan data**, lalu **Pulihkan data** di perangkat atau versi lain.
- Di Android, file cadangan tersimpan di **Documents › FinancialFreedom**.

---

## Bagian 2: Merawat dan mengubah kode

### Alur kerja
1. Ubah file di folder **`src/`**. Jangan mengedit `www/index.html` atau `desktop/index.html` langsung, karena keduanya ditulis ulang setiap build.
2. Upload perubahan ke GitHub. Semua workflow menjalankan `build.py` lebih dulu, lalu membangun APK, versi web, dan versi desktop.
3. Untuk mencoba di komputer: jalankan `python3 build.py`, lalu buka `dist/financial-freedom.html` di Chrome. Skrip ini butuh Python 3 dan tidak memerlukan paket tambahan.

### Struktur folder

```
src/
  shell/        Kerangka HTML: head, body, dan pembungkus untuk tiap versi
  styles/
    tokens.css      Warna, font, tema terang & gelap
    base.css        Reset dasar, body, tombol
    layout.css      Header, judul seksi, navigasi bawah
    components.css  Kartu ringkasan, kartu rekening, daftar transaksi, filter, lembar (sheet)
    views.css       Halaman Statistik dan Tabungan
    category.css    Rincian & pos anggaran per kategori
    scan.css        Scan struk, tombol file, toast
    motion.css      Animasi (harus paling akhir)
    desktop.css     Khusus versi desktop
  js/
    core/
      icons.js      Ikon SVG dan fungsi ic()
      config.js     Daftar kategori, jenis rekening, jenis tabungan
      format.js     Format rupiah, tanggal, angka
      state.js      State aplikasi (S) dan fungsi hitung (saldo, total, dll.)
      storage.js    Simpan & muat data (akun Claude atau perangkat)
    ui/
      render.js     render(), animasi angka, pemilih bulan
      sheet.js      Lembar bawah (bottom sheet) dan toast
    views/          Halaman: home.js, transactions.js, stats.js, assets.js
    sheets/         Formulir: transaksi, rekening, tabungan, menu tambah, pengaturan
    features/
      category.js   Rincian pengeluaran & pos anggaran per kategori
      scan.js       Pilih/ambil foto struk
      ocr.js        Baca struk di perangkat (versi di luar Claude)
      scan-claude.js Baca struk oleh Claude (versi di Claude)
      files.js      Ekspor CSV, cadangkan, pulihkan
      demo.js       Data contoh
      native.js     Status bar & tombol Kembali Android
    app/
      actions.js    Aksi tombol (atribut data-act)
      events.js     Klik, ketik, ubah, dan simpan formulir
    main.js         init(), titik awal aplikasi
desktop/        Kode Electron (main.js) dan ikon untuk versi Windows
www/            Hasil build untuk APK dan versi web (+ manifest, service worker, ikon)
assets/         Ikon & layar pembuka APK
keystore/       Kunci tanda tangan APK (jangan dihapus)
build.py        Menggabungkan src/ menjadi semua versi
```

### Aturan penting
- Semua file JS digabung menjadi satu, sesuai urutan daftar `SCRIPTS` di `build.py`. Kalau menambah file baru, daftarkan di sana. Letakkan file itu **setelah** file-file yang kodenya dipakai saat aplikasi dimuat.
- Tombol memakai atribut `data-act="namaAksi"`. Aksinya ditangani di `src/js/app/actions.js`.
- Formulir ditangani di `src/js/app/events.js`, dalam bagian `submit`, berdasarkan `id` formulir.
- Semua warna diambil dari variabel di `tokens.css`, supaya tema terang dan gelap tetap konsisten.

### Contoh perubahan umum
- **Menambah kategori pengeluaran:** tambahkan satu baris di daftar `OUT` dalam `src/js/core/config.js`. Formatnya `{id, n: nama, i: ikon, c: warna}`. Ikon diambil dari `icons.js`, warna dari `--c1` sampai `--c10`.
- **Menambah jenis rekening:** tambahkan di `ACCTYPES` dalam file yang sama.
- **Mengubah teks atau tampilan sebuah halaman:** buka file yang sesuai di `src/js/views/`.
- **Mengganti versi aplikasi:** ubah `version` di `package.json`.
