@echo off
setlocal
set "APPDIR=%~dp0"
set "EXE=%APPDIR%Financial Freedom.exe"
set "ICO=%APPDIR%resources\app\icon.ico"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$w = New-Object -ComObject WScript.Shell;" ^
  "foreach ($dir in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {" ^
  "  $s = $w.CreateShortcut((Join-Path $dir 'Financial Freedom.lnk'));" ^
  "  $s.TargetPath = $env:EXE; $s.WorkingDirectory = $env:APPDIR; $s.IconLocation = $env:ICO; $s.Description = 'Catatan keuangan pribadi'; $s.Save() }"
if errorlevel 1 (
  echo Gagal membuat shortcut. Coba klik kanan file ini lalu pilih "Run as administrator".
) else (
  echo Shortcut Financial Freedom sudah dibuat di Desktop dan Start Menu.
)
pause
