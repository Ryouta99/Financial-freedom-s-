"use strict";
const { app, BrowserWindow, Menu, shell, session, screen } = require("electron");
const path = require("path");
const fs = require("fs");

app.setName("Financial Freedom");
if (process.platform === "win32") app.setAppUserModelId("com.financialfreedom.desktop");

if (!app.requestSingleInstanceLock()) { app.quit(); }

const stateFile = () => path.join(app.getPath("userData"), "window-state.json");
function loadState() {
  try { return JSON.parse(fs.readFileSync(stateFile(), "utf8")); } catch (e) { return null; }
}
function saveState(win) {
  try {
    if (win.isMinimized()) return;
    const b = win.getNormalBounds();
    fs.writeFileSync(stateFile(), JSON.stringify({ ...b, maximized: win.isMaximized() }));
  } catch (e) {}
}
function visible(b) {
  return screen.getAllDisplays().some(d => { const a = d.workArea;
    return b.x < a.x + a.width - 60 && b.x + b.width > a.x + 60 && b.y >= a.y - 10 && b.y < a.y + a.height - 60; });
}

let win = null;
function createWindow() {
  const st = loadState();
  const opts = {
    width: 480, height: 880, minWidth: 380, minHeight: 600,
    title: "Financial Freedom",
    backgroundColor: "#F2F3F8",
    icon: path.join(__dirname, process.platform === "win32" ? "icon.ico" : "icon.png"),
    autoHideMenuBar: true,
    show: false,
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true, spellcheck: false }
  };
  if (st && visible(st)) Object.assign(opts, { x: st.x, y: st.y, width: st.width, height: st.height });
  win = new BrowserWindow(opts);
  if (st && st.maximized) win.maximize();
  win.once("ready-to-show", () => win.show());

  // Links that leave the app open in the normal browser.
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//i.test(url)) shell.openExternal(url);
    return { action: "deny" };
  });
  win.webContents.on("will-navigate", (e, url) => {
    if (!url.startsWith("file://")) { e.preventDefault(); if (/^https?:\/\//i.test(url)) shell.openExternal(url); }
  });

  // Ask where to save backups and CSV exports.
  win.webContents.session.on("will-download", (e, item) => {
    const name = item.getFilename();
    if (process.env.FF_SAVE_DIR) { item.setSavePath(path.join(process.env.FF_SAVE_DIR, name)); return; }
    item.setSaveDialogOptions({
      title: "Simpan file",
      defaultPath: path.join(app.getPath("documents"), name),
      filters: name.endsWith(".json") ? [{ name: "Cadangan Financial Freedom", extensions: ["json"] }]
             : name.endsWith(".csv") ? [{ name: "CSV (Excel)", extensions: ["csv"] }] : []
    });
  });

  ["resize", "move"].forEach(ev => win.on(ev, () => { clearTimeout(win._st); win._st = setTimeout(() => saveState(win), 400); }));
  win.on("close", () => saveState(win));

  win.loadFile(path.join(__dirname, "index.html"));
}

app.on("second-instance", () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });

app.whenReady().then(() => {
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    { label: "Aplikasi", submenu: [
      { role: "reload", label: "Muat ulang" },
      { role: "togglefullscreen", label: "Layar penuh" },
      { type: "separator" },
      { role: "zoomIn", label: "Perbesar" }, { role: "zoomOut", label: "Perkecil" }, { role: "resetZoom", label: "Ukuran normal" },
      { type: "separator" },
      { role: "quit", label: "Keluar" }
    ] },
    { label: "Edit", submenu: [ { role: "undo", label: "Urungkan" }, { role: "redo", label: "Ulangi" }, { type: "separator" },
      { role: "cut", label: "Potong" }, { role: "copy", label: "Salin" }, { role: "paste", label: "Tempel" }, { role: "selectAll", label: "Pilih semua" } ] }
  ]));
  // No camera, microphone, location or notifications are needed; refuse them all.
  session.defaultSession.setPermissionRequestHandler((wc, perm, cb) => cb(perm === "clipboard-sanitized-write"));
  createWindow();
});

app.on("window-all-closed", () => app.quit());
