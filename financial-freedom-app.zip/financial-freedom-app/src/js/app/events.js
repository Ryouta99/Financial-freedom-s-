document.addEventListener("click", e => {
  const tabBtn = e.target.closest(".nav [data-tab]");
  if (tabBtn){ go(tabBtn.dataset.tab); return; }
  const el = e.target.closest("[data-act]"); if (!el || el.disabled) return;
  if (el.dataset.act==="close" && el.classList.contains("scrim") && Date.now()-(S.sheetOpenAt||0) < 350) return;
  e.preventDefault(); handle(el);
});
function imageFromTransfer(dt){ if (!dt) return null; for (const it of dt.items || []) if (it.kind==="file" && /^image\//.test(it.type)) return it.getAsFile(); for (const f of dt.files || []) if (/^image\//.test(f.type)) return f; return null; }
document.addEventListener("paste", e => { if (!$("#scanBox")) return; const f = imageFromTransfer(e.clipboardData); e.preventDefault();
  if (f) scanPreview(f); else { const z = $("#pasteZone"); if (z) z.textContent = ""; toast("Yang ditempel bukan foto. Salin fotonya dari Galeri dulu."); } });
document.addEventListener("dragover", e => { if ($("#scanBox")) e.preventDefault(); });
document.addEventListener("drop", e => { if (!$("#scanBox")) return; e.preventDefault(); const f = imageFromTransfer(e.dataTransfer); if (f) scanPreview(f); });
document.addEventListener("keydown", e => { if (e.key==="Escape" && $("#sheet").classList.contains("open")) closeSheet(); });
document.addEventListener("input", e => {
  const t = e.target;
  if (t.matches("[data-money]")){ const n = parseRp(t.value); t.value = n ? fmtNum(n) : ""; }
  if (t.id==="aNo"){ t.value = t.value.replace(/\D/g,"").slice(0,4); }
  if (t.name && t.name.startsWith("cb_")) updateCatBudgetTotal();
  if (t.id==="q"){ S.q = t.value; const b = $("#txBody"); if (b) b.innerHTML = txListHTML(); }
});
document.addEventListener("change", e => {
  const t = e.target;
  if (t.closest("#txForm") && t.name==="type"){ const d = readTxDraft(); $("#txFields").innerHTML = txFields({...d, type:t.value}); }
  if (t.closest("#svForm") && t.name==="type"){ $("#balWrap").innerHTML = balField(t.value, 0); }
  if (t.closest("#moveForm") && t.name==="dir"){ $("#mAccLbl").textContent = t.value==="1" ? "Ambil dana dari rekening" : "Masukkan dana ke rekening"; }
  if (t.id==="accFilter"){ S.accFilter = t.value; render(); }
  if ((t.id==="scanCam"||t.id==="scanGal") && t.files && t.files[0]) scanPreview(t.files[0]);
  if (t.id==="restoreFile" && t.files && t.files[0]) readBackup(t.files[0]);
});

function ensureAcc(v){
  if (v && v!=="__auto") return v;
  const id = uid("a_"); put(id, {kind:"acc", name:"Dompet Tunai", type:"tunai", init:0, ts:Date.now()}); toast("Rekening Dompet Tunai dibuat."); return id;
}
document.addEventListener("submit", e => {
  e.preventDefault(); const f = e.target; const fid = f.getAttribute("id"); const fd = new FormData(f);
  const showErr = (sel,msg) => { const er=$(sel); er.textContent=msg; er.hidden=false; };
  if (fid==="txForm"){
    const amount = parseRp(fd.get("amount")), type = fd.get("type");
    if (amount<=0) return showErr("#txErr","Isi nominal lebih dari Rp 0.");
    const id = fd.get("rid") || uid("t_"); const prev = S.docs.get(id) || {};
    const date = fd.get("date") || today(), note = String(fd.get("note")||"").trim();
    let doc;
    if (type==="tf"){
      const from = fd.get("acc"), to = fd.get("to");
      if (!from || !to || from==="__auto" || to==="__auto") return showErr("#txErr","Pilih rekening asal dan tujuan.");
      if (from===to) return showErr("#txErr","Rekening asal dan tujuan harus berbeda.");
      doc = {kind:"tx", type:"tf", amount, acc:from, to, date, note, ts:prev.ts||Date.now()};
      const fee = parseRp(fd.get("fee"));
      if (fee>0){ const feeId = prev.feeId || uid("t_"); doc.fee = fee; doc.feeId = feeId;
        put(feeId, {kind:"tx", type:"out", amount:fee, category:"tagihan", acc:from, date, note:"Biaya admin transfer", ts:Date.now(), feeOf:id}); }
      else if (prev.feeId){ del(prev.feeId); }
    } else {
      const acc = ensureAcc(fd.get("acc"));
      doc = {kind:"tx", type, amount, category:fd.get("cat"), acc, date, note, ts:prev.ts||Date.now()};
      if (S.formItems && S.formItems.length) doc.items = S.formItems; else if (prev.items) doc.items = prev.items;
      if (S.formScanned || prev.scanned) doc.scanned = true;
      if (prev.feeOf) doc.feeOf = prev.feeOf;
    }
    if (prev.demo) doc.demo = true;
    put(id, doc); closeSheet(); toast(fd.get("rid")?"Perubahan disimpan.":type==="tf"?"Transfer tercatat.":"Transaksi tersimpan.");
    if (!date.startsWith(S.month)){ S.month = date.slice(0,7); render(); }
  }
  if (fid==="accForm"){
    const name = String(fd.get("name")||"").trim(); if (!name) return showErr("#accErr","Beri nama rekening.");
    const type = fd.get("type"); const init = parseRp(fd.get("init")) * (type==="kartu" ? -1 : 1);
    const id = fd.get("rid") || uid("a_"); const prev = S.docs.get(id) || {};
    const doc = {kind:"acc", name, type, init, no:String(fd.get("no")||"").slice(0,4), ts:prev.ts||Date.now()};
    if (prev.demo) doc.demo = true;
    put(id, doc);
    if (fd.get("back") && S.draft){ const d = S.draft; S.draft = null; if (d.type==="tf"){ if (!d.acc||d.acc==="__auto") d.acc=id; else d.to=id; } else d.acc = id; txForm(d); }
    else { closeSheet(); toast(fd.get("rid")?"Rekening diperbarui.":"Rekening ditambahkan."); }
  }
  if (fid==="svForm"){
    const type = fd.get("type"), name = String(fd.get("name")||"").trim();
    const bal = type==="emas" ? parseDec(fd.get("bal")) : parseRp(fd.get("bal"));
    if (!name) return showErr("#svErr","Beri nama pos tabungan.");
    const id = fd.get("rid") || uid("s_"); const prev = S.docs.get(id) || {};
    const hist = (prev.hist||[]).slice(); const diff = bal - (prev.bal||0);
    if (!prev.kind || prev.type!==type){ hist.length=0; if (bal) hist.push({d:today(),a:bal,n:"Saldo awal"}); }
    else if (diff) hist.push({d:today(),a:diff,n:"Koreksi saldo"});
    const doc = {kind:"sv", name, type, bal, target:parseRp(fd.get("target")), ts:prev.ts||Date.now(), hist:hist.slice(-60)};
    if (prev.demo) doc.demo = true;
    put(id, doc); closeSheet(); toast("Tabungan tersimpan.");
  }
  if (fid==="moveForm"){
    const id = fd.get("rid"), s = S.docs.get(id); if (!s) return; const gold = s.type==="emas";
    const amt = gold ? parseDec(fd.get("amt")) : parseRp(fd.get("amt")); const dir = Number(fd.get("dir"));
    const acc = fd.get("acc"); const money = gold ? parseRp(fd.get("rp")) : amt;
    if (amt<=0) return showErr("#mvErr", gold?"Isi berat emas dalam gram.":"Isi jumlah yang disetor atau ditarik.");
    if (dir<0 && amt > (s.bal||0)+1e-9) return showErr("#mvErr","Penarikan melebihi saldo tabungan.");
    if (acc && acc!=="__auto" && money<=0) return showErr("#mvErr","Isi nominal Rp yang dipindahkan dari/ke rekening.");
    const delta = Math.round(dir*amt*1000)/1000;
    let note = String(fd.get("note")||"").trim();
    if (acc && acc!=="__auto"){
      const txId = uid("t_"); const svRef = "sv:"+id;
      put(txId, {kind:"tx", type:"tf", amount:money, acc: dir>0?acc:svRef, to: dir>0?svRef:acc, sv:id, svDelta:delta, date:today(), note: note || (dir>0?"Setor ke "+s.name:"Tarik dari "+s.name), ts:Date.now()});
      note = (note?note+" · ":"") + (dir>0?"dari ":"ke ") + endName(acc);
    }
    const doc = {...s, bal: Math.round(((s.bal||0) + delta)*1000)/1000, hist:[...(s.hist||[]), {d:today(), a:delta, n:note}].slice(-60)};
    put(id, doc); svDetail(id); toast(dir>0?"Setoran dicatat.":"Penarikan dicatat.");
  }
  if (fid==="catBudgetForm") saveCatBudgets(fd);
  if (fid==="setForm"){
    const doc = {...settings(), kind:"settings", budget:parseRp(fd.get("budget")), goldPrice:parseRp(fd.get("goldPrice"))};
    put("settings", doc); closeSheet(); toast("Pengaturan disimpan.");
  }
});
