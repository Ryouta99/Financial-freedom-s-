/* ---------- actions ---------- */
function confirmBtn(el){ if (el.dataset.sure) return true; el.dataset.sure="1"; el.textContent="Yakin hapus?"; el.style.whiteSpace="nowrap"; setTimeout(()=>{ if (el.isConnected && el.dataset.sure){ delete el.dataset.sure; el.innerHTML=ic("trash"); } },4000); return false; }
function go(tab){ S.tab = tab; S.anim = true; closeSheet(); render(); window.scrollTo({top:0}); }

function handle(el){
  const a = el.dataset.act, id = el.dataset.id;
  switch(a){
    case "close": closeSheet(); break;
    case "add": addMenu(); break;
    case "tab": go(el.dataset.tab); break;
    case "goAssets": S.assetView = el.dataset.v||"acc"; go("assets"); break;
    case "assetView": S.assetView = el.dataset.v; S.anim = true; render(); break;
    case "prevMonth": S.month = addMonth(S.month,-1); S.anim = true; render(); break;
    case "nextMonth": if (S.month < ymOf(new Date())){ S.month = addMonth(S.month,1); S.anim = true; render(); } break;
    case "filter": S.filter = el.dataset.f; render(); break;
    case "clearAccFilter": S.accFilter = ""; render(); break;
    case "statType": S.statType = el.dataset.t; S.anim = true; render(); break;
    case "newTx": txForm({type:el.dataset.type||"out"}); break;
    case "newTxFrom": { const ty = el.dataset.type; txForm(ty==="in"?{type:"in",acc:id}:ty==="tf"?{type:"tf",acc:id}:{type:"out",acc:id}); break; }
    case "editTx": { const t = S.docs.get(id); if (t) txForm({...t,id}); break; }
    case "delTx": if (confirmBtn(el)) deleteTx(id); break;
    case "newAccInline": S.draft = readTxDraft(); accForm({}, true); break;
    case "newAcc": accForm({}); break;
    case "openAcc": accDetail(id); break;
    case "editAcc": { const x = S.docs.get(id); if (x) accForm({...x,id}); break; }
    case "delAcc": if (confirmBtn(el)){ const n = allTx().filter(t=>touchesAcc(t,id)).length; del(id); if (S.accFilter===id) S.accFilter=""; closeSheet(); toast(n?`Rekening dihapus. ${n} transaksi kini tanpa rekening.`:"Rekening dihapus."); } break;
    case "traceAcc": S.accFilter = id; S.filter = "all"; const fst = allTx().find(t=>touchesAcc(t,id)); if (fst && !fst.date.startsWith(S.month)) S.month = fst.date.slice(0,7); go("tx"); break;
    case "scan": scanSheet(); break;
    case "readReceipt": readReceipt(); break;
    case "newSv": svForm({}); break;
    case "openSv": svDetail(id); break;
    case "editSv": { const s = S.docs.get(id); if (s) svForm({...s,id}); break; }
    case "delSv": if (confirmBtn(el)){ del(id); closeSheet(); toast("Pos tabungan dihapus."); } break;
    case "goldPrice": settingsSheet(true); break;
    case "settings": settingsSheet(false); break;
    case "loadDemo": loadDemo(); break;
    case "clearDemo": clearDemo(); break;
    case "export": closeSheet(); exportCSV(); break;
    case "openCat": catDetail(id); break;
    case "catBudgets": catBudgetForm(id); break;
    case "newTxCat": txForm({type:"out", category:id}); break;
    case "backup": closeSheet(); backupData(); break;
    case "shareBackup": closeSheet(); backupData(true); break;
    case "confirmRestore": confirmRestore(); break;
    case "toggleHide": S.hide = !S.hide; try{ localStorage.setItem(HKEY, S.hide?"1":"0"); }catch(e){} render(); toast(S.hide?"Saldo, tabungan & pemasukan disembunyikan.":"Semua nominal ditampilkan."); break;
    case "copyLink": (async () => { try{ await navigator.clipboard.writeText(APP_URL); toast("Tautan disalin. Tempel di Chrome."); }
      catch(e){ const c = document.querySelector(".applink"); if (c){ const r = document.createRange(); r.selectNodeContents(c); const sel = getSelection(); sel.removeAllRanges(); sel.addRange(r); } toast("Tekan lama tautan di bawah untuk menyalin."); } })(); break;
  }
}
function deleteTx(id){
  const t = S.docs.get(id); if (!t) return;
  if (t.type==="tf" && t.sv && t.svDelta){ const s = S.docs.get(t.sv); if (s){ const ns = {...s, bal: Math.round(((s.bal||0)-t.svDelta)*1000)/1000, hist:[...(s.hist||[]), {d:today(), a:-t.svDelta, n:"Dibatalkan"}].slice(-60)}; put(t.sv, ns); } }
  if (t.feeId && S.docs.get(t.feeId)) del(t.feeId);
  del(id); closeSheet(); toast("Transaksi dihapus.");
}
