async function init(){
  render();
  const C = window.claude;
  if (!C || typeof C.use!=="function"){ useLocal(); return; }
  S.samplePromise = C.use("sample"); S.samplePromise.then(s => { S.sample=s; }).catch(()=>{});
  C.use("downloads").then(d => { S.dl=d; }).catch(()=>{});
  let db=null, user=null, id=null;
  try{ [db,user] = await Promise.all([C.use("db"), C.use("user")]); }catch(e){}
  if (db && user){ try{ id = await user.id(); }catch(e){} }
  if (!db || !id){ useLocal(); return; }
  S.mode="cloud";
  S.col = db.collection("data/users/" + id);
  let last = new Map();
  S.col.onSnapshot(snap => {
    const m = new Map(); snap.docs.forEach(d => m.set(d.id, d.data()));
    let changed = !S.ready || m.size !== last.size; if (!S.ready) S.anim = true;
    if (!changed) for (const [k,v] of m){ if (last.get(k) !== v){ changed = true; break; } }
    last = m; S.docs = m; S.ready = true;
    if (changed) scheduleRender();
  }, () => { if (!S.ready) useLocal(); else toast("Sinkronisasi terhenti. Muat ulang halaman."); });
}
init();
