/* ---------- expense breakdown & budget per category ("pos anggaran") ----------
   Monthly limits live in settings().catBudgets as { categoryId: amount }.
   Spending is always computed from the month's "out" transactions, so nothing
   here needs to be stored except the limits themselves. */

const catBudgets = () => settings().catBudgets || {};
const catOf = t => (CAT[t.category] && OUT.some(c => c.id === t.category)) ? t.category : "lainnya";

/** Total spent per expense category in one month: { categoryId: amount }. */
function catSpending(ym){
  const by = {};
  monthTx(ym, "out").forEach(t => { const k = catOf(t); by[k] = (by[k] || 0) + (t.amount || 0); });
  return by;
}

/** Average monthly spending of a category over the 3 months before `ym`. */
function catAverage(id, ym){
  let total = 0;
  for (let k = 1; k <= 3; k++) total += catSpending(addMonth(ym, -k))[id] || 0;
  return total / 3;
}

/** Status of one category against its limit: "" (fine), "warn" (≥ 80 %) or "over". */
function catState(spent, budget){
  if (!budget) return "";
  return spent > budget ? "over" : spent >= budget * 0.8 ? "warn" : "";
}

/** Categories with spending or a limit this month, limited ones first. */
function catRows(ym){
  const b = catBudgets(), sp = catSpending(ym);
  return OUT.map(c => ({ ...c, spent: sp[c.id] || 0, budget: b[c.id] || 0 }))
    .filter(r => r.spent > 0 || r.budget > 0)
    .sort((x, y) => (y.budget > 0) - (x.budget > 0) || y.spent - x.spent);
}

function catLine(r){
  const state = catState(r.spent, r.budget);
  const pct = r.budget ? Math.min(100, r.spent / r.budget * 100) : null;
  const sub = !r.budget ? "Belum ada pos anggaran"
    : r.spent > r.budget ? `Lewat ${rp(r.spent - r.budget)}`
    : `Sisa ${rp(r.budget - r.spent)}`;
  return `<button type="button" class="cat-line" data-act="openCat" data-id="${r.id}" style="--cc:var(${r.c})">${catIcon(r.id)}
    <span class="meta"><b>${esc(r.n)}</b><small class="${state}">${sub}</small></span>
    <span class="val num">${rp(r.spent)}${r.budget ? `<small>dari ${rp(r.budget)}</small>` : ""}</span>
    ${pct !== null ? `<span class="bar ${state}"><i style="width:${pct}%"></i></span>` : ""}</button>`;
}

/** "Rincian pengeluaran" section on the home screen. */
function categoryCard(){
  const rows = catRows(S.month);
  if (!rows.length){
    if (!allTx().length) return "";
    return `<div class="sec"><div class="sec-h"><h2>Rincian pengeluaran</h2></div>
      <button type="button" class="card rowcard" data-act="catBudgets"><span class="qi out">${ic("target")}</span><span class="grow"><b style="display:block">Atur pos anggaran</b><small>Tentukan batas untuk Pendidikan, Makan, Transportasi, dan lainnya</small></span>${ic("chevR")}</button></div>`;
  }
  const limited = rows.filter(r => r.budget);
  const over = limited.filter(r => r.spent > r.budget).length;
  const note = !limited.length ? `<button type="button" class="link" data-act="catBudgets">Atur pos</button>`
    : `<button type="button" class="link" data-act="catBudgets">${over ? `${over} pos lewat batas` : "Atur pos"}</button>`;
  return `<div class="sec"><div class="sec-h"><h2>Rincian pengeluaran</h2>${note}</div>
    <div class="card cat-list">${rows.map(catLine).join("")}</div></div>`;
}

/** Bottom sheet: one category's spending, limit and transactions this month. */
function catDetail(id){
  const c = CAT[id]; if (!c) return;
  const list = monthTx(S.month, "out").filter(t => catOf(t) === id);
  const spent = sum(list), budget = catBudgets()[id] || 0, prev = catSpending(addMonth(S.month, -1))[id] || 0;
  const state = catState(spent, budget);
  const pct = budget ? Math.min(100, spent / budget * 100) : 0;
  let compare = "";
  if (prev > 0 && spent > 0){
    const d = Math.round((spent - prev) / prev * 100);
    compare = `<span class="chip ${d <= 0 ? "good" : "bad"}">${d >= 0 ? "▲" : "▼"} ${Math.abs(d)}% vs bulan lalu</span>`;
  }
  openSheet(c.n, `<div class="form">
    <div class="card cat-summary" style="--cc:var(${c.c})">
      <div class="cat-summary-top">${catIcon(id)}<span><small>Terpakai ${esc(monthName(S.month))}</small><b class="num">${rp(spent)}</b></span></div>
      ${budget ? `<div class="bar ${state}"><i style="width:${pct}%"></i></div>
        <div class="cat-summary-row"><span>${spent > budget ? `Lewat <b class="num">${rp(spent - budget)}</b>` : `Sisa <b class="num">${rp(budget - spent)}</b>`}</span><span>Pos <b class="num">${rp(budget)}</b></span></div>`
        : `<p class="hint">Belum ada pos anggaran untuk kategori ini.</p>`}
      <div class="cat-summary-row"><span>${list.length} transaksi</span>${compare}</div>
    </div>
    <div class="row2"><button type="button" class="btn ghost" data-act="catBudgets" data-id="${id}">${ic("target")}${budget ? "Ubah pos" : "Atur pos"}</button><button type="button" class="btn ghost" data-act="newTxCat" data-id="${id}">${ic("plus")}Catat</button></div>
    <div><div class="lbl">Transaksi bulan ini</div>
      ${list.length ? `<div class="tx-list">${list.map(t => txRowDated(t)).join("")}</div>` : `<p class="hint">Belum ada pengeluaran ${esc(c.n.toLowerCase())} di ${esc(monthName(S.month))}.</p>`}</div>
  </div>`);
}

/** Bottom sheet: set the monthly limit of every expense category. */
function catBudgetForm(focusId){
  const b = catBudgets();
  openSheet("Pos anggaran bulanan", `<form id="catBudgetForm" class="form" novalidate>
    <p class="hint">Tentukan batas pengeluaran tiap kategori per bulan, misalnya Pendidikan, Makan, dan Transportasi. Kosongkan kategori yang tidak ingin dibatasi.</p>
    <div class="cat-budget-list">${OUT.map(c => {
      const avg = catAverage(c.id, S.month);
      return `<label class="cat-budget-row" style="--cc:var(${c.c})" for="cb_${c.id}">${catIcon(c.id)}
        <span class="nm">${esc(c.n)}<small>${avg ? `Rata-rata 3 bulan: ${rp(avg)}` : "Belum ada riwayat"}</small></span>
        <input class="inp num" id="cb_${c.id}" name="cb_${c.id}" inputmode="numeric" data-money placeholder="Rp 0" value="${b[c.id] ? fmtNum(b[c.id]) : ""}"></label>`;
    }).join("")}</div>
    <div class="cat-total" id="cbTotal">${catBudgetTotalHTML(Object.values(b).reduce((a, v) => a + (v || 0), 0))}</div>
    <button class="btn block" type="submit">Simpan pos anggaran</button>
  </form>`);
  if (focusId) setTimeout(() => { const el = $("#cb_" + focusId); if (el){ el.focus({preventScroll:true}); el.scrollIntoView({block:"center"}); } }, 250);
}

function catBudgetTotalHTML(total){
  const overall = settings().budget || 0;
  let line = "";
  if (overall && total){
    line = total > overall ? `<span class="over">Melebihi anggaran bulanan (${rp(overall)}) sebesar ${rp(total - overall)}.</span>`
      : `<span>Anggaran bulanan ${rp(overall)} · belum dialokasikan ${rp(overall - total)}</span>`;
  } else if (total && !overall){
    line = `<span>Total ini akan dipakai sebagai anggaran bulanan.</span>`;
  }
  return `<div class="cat-summary-row"><span>Total pos</span><b class="num">${rp(total)}</b></div>${line}`;
}

/** Called on every keystroke in the budget form to refresh the total. */
function updateCatBudgetTotal(){
  const f = $("#catBudgetForm"); if (!f) return;
  let total = 0; f.querySelectorAll("input[name^=cb_]").forEach(i => { total += parseRp(i.value); });
  $("#cbTotal").innerHTML = catBudgetTotalHTML(total);
}

function saveCatBudgets(fd){
  const limits = {};
  OUT.forEach(c => { const v = parseRp(fd.get("cb_" + c.id)); if (v > 0) limits[c.id] = v; });
  const total = Object.values(limits).reduce((a, v) => a + v, 0);
  const st = settings();
  const doc = { ...st, kind: "settings", catBudgets: limits };
  if (!st.budget && total) doc.budget = total;
  put("settings", doc); closeSheet();
  toast(Object.keys(limits).length ? "Pos anggaran disimpan." : "Pos anggaran dikosongkan.");
}
