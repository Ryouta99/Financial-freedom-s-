/* ---------- files: export, backup, restore ---------- */
const CAP = (window.Capacitor && typeof window.Capacitor.isNativePlatform==="function" && window.Capacitor.isNativePlatform()) ? window.Capacitor : null;
const plug = n => (CAP && CAP.Plugins && CAP.Plugins[n]) || null;
async function shareNative(filename, data){
  const r = await plug("Filesystem").writeFile({path:filename, data, directory:"CACHE", encoding:"utf8"});
  await plug("Share").share({title:filename, url:r.uri, dialogTitle:"Simpan atau kirim file"});
  return "shared";
}
async function saveFile(filename, data, mime, opts={}){
  if (CAP && plug("Filesystem")){
    const fsys = plug("Filesystem");
    if (opts.share && plug("Share")) return shareNative(filename, data);
    try{
      try{ if (fsys.requestPermissions) await fsys.requestPermissions(); }catch(_){}
      await fsys.writeFile({path:"FinancialFreedom/"+filename, data, directory:"DOCUMENTS", encoding:"utf8", recursive:true});
      S.lastSaved = "Documents/FinancialFreedom/" + filename;
      return "documents";
    }catch(e){
      if (plug("Share")) return shareNative(filename, data);
      throw e;
    }
  }
  if (S.dl){ await S.dl.save({filename, data}); return "saved"; }
  if (STANDALONE){ const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([data],{type:mime})); a.download = filename; document.body.appendChild(a); a.click(); a.remove(); return "downloaded"; }
  throw new Error("unavailable");
}
const savedMsg = (r, what) => r==="documents" ? `${what} tersimpan di folder Documents › FinancialFreedom.` : r==="downloaded" ? (/Electron/.test(navigator.userAgent) ? "" : `${what} tersimpan di folder Download.`) : "";
async function exportCSV(){
  const q = v => `"${String(v??"").replace(/"/g,'""')}"`;
  const rows = [["Tanggal","Jenis","Kategori","Nominal","Rekening","Ke rekening","Catatan"].join(",")].concat(
    allTx().map(t=>[t.date, t.type==="in"?"Pemasukan":t.type==="out"?"Pengeluaran":"Transfer", t.type==="tf"?"":(CAT[t.category]?.n||""), t.amount,
      t.acc?endName(t.acc):(LEGACY_METHODS[t.method]||""), t.type==="tf"?endName(t.to):"", t.note].map(q).join(",")));
  const data = "﻿"+rows.join("\n");
  try{ const r = await saveFile(`financial-freedom-${today()}.csv`, data, "text/csv"); const m = savedMsg(r, "File CSV"); if (m) toast(m); }
  catch(e){ if (e && e.message==="unavailable"){ try{ await navigator.clipboard.writeText(data); toast("Unduhan tidak tersedia di sini. Data CSV disalin ke clipboard."); }catch(_){ toast("Unduhan tidak tersedia di tampilan ini."); } } else toast("Ekspor dibatalkan."); }
}
async function backupData(share){
  const docs = {}; S.docs.forEach((v,k)=>{ docs[k]=v; });
  const data = JSON.stringify({app:"financial-freedom", version:1, exported:new Date().toISOString(), docs});
  try{
    const name = `cadangan-financial-freedom-${today()}.json`;
    const r = await saveFile(name, data, "application/json", {share:!!share});
    try{ localStorage.setItem("ff-last-backup", today()); }catch(_){}
    render();
    if (r==="documents") backupSavedSheet(name);
    else { const m = savedMsg(r, "File cadangan"); if (m) toast(m); }
  }catch(e){ toast(e && e.message==="unavailable" ? "Cadangan tidak bisa disimpan di tampilan ini." : "Cadangan dibatalkan."); }
}
/** Shown after a backup is written on Android: where the file is and how to find it. */
function backupSavedSheet(name){
  openSheet("Cadangan tersimpan", `<div class="form">
    <div class="card saved-file"><span class="qi in">${ic("download")}</span>
      <span class="grow"><b>${esc(name)}</b><small>Penyimpanan internal › Documents › FinancialFreedom</small></span></div>
    <div><div class="lbl">Cara menemukannya</div>
      <ol class="steps">
        <li>Buka aplikasi <b>File</b> (Files by Google / File Saya).</li>
        <li>Pilih <b>Jelajahi</b> → <b>Penyimpanan internal</b>. Jangan lewat "Terbaru" atau pencarian, karena file baru belum muncul di sana.</li>
        <li>Buka folder <b>Documents</b> → <b>FinancialFreedom</b>.</li>
      </ol></div>
    <p class="hint">Paling aman, simpan juga salinannya ke Google Drive. Kalau HP hilang atau rusak, cadangan tetap ada.</p>
    <button type="button" class="btn block" data-act="shareBackup">${ic("arrowR")}Kirim ke Drive / WhatsApp</button>
    <button type="button" class="btn ghost block" data-act="close">Selesai</button>
  </div>`);
}
async function readBackup(file){
  let obj;
  try{ obj = JSON.parse(await file.text()); }catch(e){ toast("File tidak bisa dibaca. Pilih file cadangan .json dari Financial Freedom."); return; }
  if (!obj || obj.app!=="financial-freedom" || !obj.docs || typeof obj.docs!=="object"){ toast("Ini bukan file cadangan Financial Freedom."); return; }
  const entries = Object.entries(obj.docs).filter(([k,v]) => v && typeof v==="object" && ["tx","acc","sv","settings"].includes(v.kind));
  const n = {tx:0,acc:0,sv:0}; entries.forEach(([,v]) => { if (n[v.kind]!==undefined) n[v.kind]++; });
  S.pendingRestore = entries;
  openSheet("Pulihkan data", `<div class="form">
    <div class="card" style="box-shadow:none;background:var(--surface2)"><small style="color:var(--muted)">Cadangan tanggal ${esc((obj.exported||"").slice(0,10))}</small>
      <div style="font-weight:700;margin-top:4px">${n.acc} rekening · ${n.tx} transaksi · ${n.sv} pos tabungan</div></div>
    <p class="hint">${S.mode==="cloud" ? "Isi cadangan akan ditambahkan ke data di akunmu. Catatan dengan kode yang sama akan ditimpa." : "Semua data di aplikasi ini akan <b>diganti</b> dengan isi cadangan."}</p>
    <button type="button" class="btn block" data-act="confirmRestore">Pulihkan sekarang</button>
    <button type="button" class="btn ghost block" data-act="close">Batal</button></div>`);
}
async function confirmRestore(){
  const entries = S.pendingRestore; if (!entries || busy) return; busy = true; S.pendingRestore = null; closeSheet();
  if (S.mode==="cloud"){
    entries.forEach(([k,v]) => S.docs.set(k,v)); render(); toast("Memulihkan data…");
    for (const [k,v] of entries){ try{ await S.col.doc(k).set(v); }catch(e){ toast("Sebagian data gagal dipulihkan."); break; } }
  } else { S.docs = new Map(entries); saveLocal(); render(); }
  busy = false; S.anim = true; render(); toast("Data berhasil dipulihkan.");
}
function storageOK(){ try{ const k="ff-test"; localStorage.setItem(k,"1"); const ok = localStorage.getItem(k)==="1"; localStorage.removeItem(k); return ok; }catch(e){ return false; } }
function backupReminder(){
  if (S.mode!=="local" || !allTx().length) return "";
  if (S.storageBad) return `<div class="demo-banner" style="background:var(--out-soft)">${ic("x")}<span><b>Data tidak bisa disimpan di sini.</b> Semua catatan akan hilang saat aplikasi ditutup. Pasang sebagai aplikasi atau buka lewat Chrome.</span></div>`;
  let last = null; try{ last = localStorage.getItem("ff-last-backup"); }catch(e){}
  const days = last ? Math.floor((Date.now() - new Date(last).getTime())/864e5) : null;
  if (days!==null && days < 14) return "";
  return `<div class="demo-banner">${ic("download")}<span>${last?`Cadangan terakhir ${days} hari lalu.`:"Datamu belum pernah dicadangkan."} Simpan cadangan agar aman jika HP hilang atau rusak.</span><button type="button" data-act="backup">Cadangkan</button></div>`;
}
