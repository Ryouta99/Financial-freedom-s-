/* ---------- demo ---------- */
function demoDocs(){
  let seed = 7; const rnd = () => { seed = (seed*16807)%2147483647; return (seed-1)/2147483646; };
  const pick = a => a[Math.floor(rnd()*a.length)];
  const now = Date.now(); let n = 0;
  const A = {bank:uid("a_"), cash:uid("a_"), ew:uid("a_"), cc:uid("a_")};
  const docs = [
    [A.bank,{kind:"acc",name:"Rekening Gaji",type:"bank",init:4200000,no:"4821",ts:now+n++,demo:true}],
    [A.cash,{kind:"acc",name:"Dompet",type:"tunai",init:350000,ts:now+n++,demo:true}],
    [A.ew,{kind:"acc",name:"E-wallet",type:"ewallet",init:120000,ts:now+n++,demo:true}],
    [A.cc,{kind:"acc",name:"Kartu Kredit",type:"kartu",init:0,no:"1907",ts:now+n++,demo:true}]
  ];
  const T = [["makan",["Nasi padang","Kopi susu","Bakso","Makan siang kantor","Martabak"],15000,65000,[A.cash,A.ew]],["transport",["Ojek online","Bensin","KRL","Parkir"],8000,120000,[A.ew,A.cash]],
    ["belanja",["Belanja bulanan","Sayur & lauk","Minimarket"],40000,450000,[A.cc,A.bank,A.cash]],["hiburan",["Nonton bioskop","Langganan musik"],50000,120000,[A.cc,A.ew]],["kesehatan",["Apotek"],25000,150000,[A.cash,A.bank]]];
  const out = []; const nowD = new Date(); const cur = ymOf(nowD);
  for (let k=5;k>=0;k--){
    const ym = addMonth(cur,-k), maxDay = ym===cur ? nowD.getDate() : daysIn(ym); const d = x => `${ym}-${pad(Math.min(x,maxDay))}`;
    out.push({type:"in",category:"gaji",amount:8500000,date:d(1),acc:A.bank,note:"Gaji bulanan"});
    if (k%2===0) out.push({type:"in",category:"freelance",amount:Math.round((1+rnd()*2)*1e6/1e4)*1e4,date:d(14),acc:A.ew,note:"Proyek desain"});
    out.push({type:"out",category:"rumah",amount:1800000,date:d(2),acc:A.bank,note:"Bayar kos"});
    out.push({type:"out",category:"tagihan",amount:Math.round((300+rnd()*150))*1000,date:d(5),acc:A.bank,note:"Listrik & internet"});
    out.push({type:"out",category:"sedekah",amount:150000,date:d(6),acc:A.cash,note:"Infaq masjid"});
    out.push({type:"tf",amount:1000000,date:d(3),acc:A.bank,to:A.cash,note:"Tarik tunai ATM"});
    out.push({type:"tf",amount:300000,date:d(4),acc:A.bank,to:A.ew,note:"Isi saldo e-wallet"});
    out.push({type:"out",category:"tagihan",amount:2500,date:d(4),acc:A.bank,note:"Biaya transfer"});
    if (k>0) out.push({type:"tf",amount:600000,date:d(20),acc:A.bank,to:A.cc,note:"Bayar tagihan kartu kredit"});
    for (let j=0;j<4;j++){ const t = pick(T); out.push({type:"out",category:t[0],amount:Math.round((t[2]+rnd()*(t[3]-t[2]))/500)*500,date:d(3+Math.floor(rnd()*26)),acc:pick(t[4]),note:pick(t[1])}); }
  }
  out.filter(t=>t.date<=today()).forEach(t => docs.push([uid("t_"), {kind:"tx",...t,ts:now+n++,demo:true}]));
  const sv = [["Dana darurat","bank",12500000,20000000],["Emas Antam","emas",7.5,0],["Reksa dana pasar uang","investasi",4200000,10000000]];
  sv.forEach(([name,type,bal,target])=>docs.push([uid("s_"),{kind:"sv",name,type,bal,target,ts:now+n++,hist:[{d:today(),a:bal,n:"Saldo awal"}],demo:true}]));
  return docs;
}
let busy = false;
async function loadDemo(){
  if (busy) return; busy = true; closeSheet();
  const docs = demoDocs(); toast("Mengisi data contoh…");
  for (const [id,d] of docs) S.docs.set(id,d);
  render();
  if (S.mode==="cloud"){ for (const [id,d] of docs){ try{ await S.col.doc(id).set(d); }catch(e){ toast("Sebagian data contoh gagal tersimpan."); break; } } }
  else saveLocal();
  busy = false; toast("Data contoh siap. Hapus kapan saja dari banner kuning.");
}
async function clearDemo(){
  if (busy) return; busy = true; closeSheet();
  const ids = [...S.docs.entries()].filter(([,v])=>v&&v.demo).map(([k])=>k);
  ids.forEach(k=>S.docs.delete(k)); if (S.accFilter && !S.docs.get(S.accFilter)) S.accFilter=""; render();
  if (S.mode==="cloud"){ for (const k of ids){ try{ await S.col.doc(k).delete(); }catch(e){} } } else saveLocal();
  busy = false; toast("Data contoh dihapus.");
}
