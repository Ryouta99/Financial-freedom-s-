const rpNum = v => { if (typeof v==="number") return Math.round(v)||0; const str = String(v??"").trim().replace(/[,.]\d{1,2}$/,""); return Number(str.replace(/\D/g,""))||0; };
async function readReceipt(){
  const f = S.scanFile; if (!f) return;
  if (STANDALONE) return readOCR();
  const s = S.sample; if (!s){ txForm({type:"out", category:"belanja"}); return; }
  const btn = $("#readBtn"), pv = $("#pv"), er = $("#scanErr");
  btn.disabled = true; btn.innerHTML = `<span class="spin"></span>Membaca struk…`; pv.classList.add("reading"); er.hidden = true;
  const cats = OUT.map(c=>`${c.id} (${c.n})`).join(", ");
  const prompt = `Foto ini adalah struk belanja atau nota pembayaran di Indonesia. Baca isinya dengan teliti.
Balas HANYA dengan satu objek JSON:
{"merchant": string (nama toko/tempat, singkat), "date": "YYYY-MM-DD" atau null, "total": number (total akhir yang dibayar, dalam rupiah, bilangan bulat), "category": salah satu id berikut: ${cats}, "method": "tunai" | "bank" | "ewallet" | "kartu" | null (cara bayar yang tertulis: tunai/cash, debit/transfer/QRIS bank, e-wallet, kartu kredit), "items": [{"name": string, "qty": number, "price": number (harga total baris, rupiah)}]}
Aturan: di struk Indonesia titik adalah pemisah ribuan (12.500 = 12500). Ambil TOTAL setelah diskon/pajak. Maksimal 25 item. Jika foto bukan struk atau tidak terbaca, balas {"error": "alasan singkat"}.
Contoh: {"merchant":"Toko Sumber Rejeki","date":"2026-10-20","total":87500,"category":"belanja","method":"tunai","items":[{"name":"Beras 5kg","qty":1,"price":72000}]}`;
  try{
    const d = await s.json(prompt, { images:[f] });
    const total = rpNum(d && d.total);
    if (!d || d.error || !(total>0)) throw {code:"unreadable"};
    const date = /^\d{4}-\d{2}-\d{2}$/.test(d.date||"") && d.date <= today() ? d.date : today();
    const items = Array.isArray(d.items) ? d.items.slice(0,25).map(i=>({name:String(i.name||"").slice(0,60), qty:Number(i.qty)||1, price:rpNum(i.price)})).filter(i=>i.name) : [];
    const accGuess = allAcc().find(a=>a.type===d.method)?.id;
    txForm({type:"out", amount:total, category: OUT.some(c=>c.id===d.category)?d.category:"belanja",
      date, acc:accGuess, note:String(d.merchant||"").slice(0,80), items, scanned:true});
  }catch(e){
    if (!$("#readBtn")) return;
    pv.classList.remove("reading"); btn.disabled=false; btn.innerHTML = `${ic("receipt")}Coba lagi`;
    const code = (e && e.code) || "upstream_error";
    const msg = {unreadable:"Struk tidak terbaca jelas. Foto ulang lebih dekat dan terang, atau isi manual.",
      not_granted:"Izin untuk Claude belum diberikan. Buka menu artefak lalu izinkan akses Claude, kemudian coba lagi.",
      sampling_disabled:"Pembacaan otomatis tidak tersedia untuk akun ini.",
      rate_limited:"Terlalu banyak permintaan atau batas pemakaian tercapai. Tunggu sebentar lalu coba lagi.",
      image_rejected:"Foto ditolak (format atau ukuran). Pilih foto lain.",
      images_unavailable:"Tampilan ini tidak bisa mengirim foto ke Claude. Coba buka lewat claude.ai di browser HP.",
      session_expired:"Sesi login habis. Masuk lagi ke Claude lalu coba lagi.",
      invalid_json:"Hasil baca tidak lengkap. Coba lagi."}[code] || "Gagal membaca struk. Coba lagi atau isi manual.";
    er.innerHTML = esc(msg) + ` <small style="opacity:.6">(${esc(code)})</small> <button type="button" class="link" data-act="newTx" data-type="out">Isi manual</button>`; er.hidden = false;
  }
}
