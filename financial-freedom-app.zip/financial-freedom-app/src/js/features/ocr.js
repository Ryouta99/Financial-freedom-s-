/* ---------- on-device OCR (used when opened outside Claude) ---------- */
const STANDALONE = !(window.claude && typeof window.claude.use === "function");
let tessLoading = null;
function loadTesseract(){
  if (window.Tesseract) return Promise.resolve(window.Tesseract);
  return tessLoading ||= new Promise((res, rej) => { const sc = document.createElement("script");
    sc.src = "https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js";
    sc.onload = () => window.Tesseract ? res(window.Tesseract) : rej(new Error("load")); sc.onerror = () => { tessLoading = null; rej(new Error("load")); };
    document.head.appendChild(sc); });
}
let ocrWorker = null;
async function ocrText(blob, onProg){
  const T = await loadTesseract();
  if (!ocrWorker) ocrWorker = await T.createWorker("ind+eng", 1, { logger: m => { if (m && m.status==="recognizing text" && onProg) onProg(m.progress); } });
  const { data } = await ocrWorker.recognize(blob);
  return data.text || "";
}
function parseReceipt(text){
  const lines = text.split(/\n/).map(l => l.replace(/\s+/g," ").trim()).filter(Boolean);
  const numRe = /(\d{1,3}(?:[.,]\d{3})+|\d{4,})(?:[.,]\d{2})?(?!\d)/g;
  const lastNum = l => { const m = [...l.matchAll(numRe)]; return m.length ? rpNum(m[m.length-1][0]) : 0; };
  const bad = /(sub\s*-?total|total\s*(item|qty|disc|diskon|hemat)|diskon|hemat|kembali|change|ppn|dpp|pajak|tax|tunai|cash|bayar\s*tunai)/i;
  let total = 0;
  const grand = lines.find(l => /(grand\s*total|total\s*bayar|total\s*belanja|total\s*harga|jumlah\s*bayar|netto)/i.test(l) && lastNum(l));
  if (grand) total = lastNum(grand);
  if (!total){ const t = lines.find(l => /\btotal\b|\bjumlah\b/i.test(l) && !bad.test(l) && lastNum(l)); if (t) total = lastNum(t); }
  if (!total){ const stop = lines.findIndex(l => /(tunai|cash|kembali|change)/i.test(l)); const pool = (stop>0 ? lines.slice(0,stop) : lines);
    total = Math.max(0, ...pool.map(lastNum).filter(n => n < 1e8)); }
  let date = null;
  for (const l of lines){
    let m = l.match(/(20\d{2})[\/\-.](\d{1,2})[\/\-.](\d{1,2})/);
    if (m){ date = `${m[1]}-${pad(+m[2])}-${pad(+m[3])}`; break; }
    m = l.match(/(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})/);
    if (m){ let y = +m[3]; if (y<100) y += 2000; const d = +m[1], mo = +m[2]; if (mo>=1 && mo<=12 && d>=1 && d<=31){ date = `${y}-${pad(mo)}-${pad(d)}`; break; } }
  }
  const merchant = (lines.find(l => (l.match(/[a-z]/gi)||[]).length >= 4 && !/(jl\.?|jalan|telp|npwp|struk|kasir|tanggal)/i.test(l)) || "").slice(0,60);
  const items = [];
  for (const l of lines){
    if (items.length >= 25) break;
    const m = l.match(/^(.*?[a-z]{2,}.*?)\s+(?:(\d{1,3})\s*[xX@]?\s+)?(?:\d{1,3}(?:[.,]\d{3})+\s+)?(\d{1,3}(?:[.,]\d{3})+)$/i);
    if (m && !/(total|jumlah|tunai|cash|kembali|ppn|diskon|hemat|bayar|harga jual|dpp|npwp)/i.test(m[1])) items.push({name:m[1].replace(/[^\w\s&.\-\/]/g,"").trim().slice(0,60), qty:+m[2]||1, price:rpNum(m[3])});
  }
  const all = text.toLowerCase();
  const catMap = [["belanja",/(indomaret|alfamart|alfamidi|supermarket|hypermart|superindo|giant|lottemart|transmart|minimarket)/],["makan",/(resto|restoran|cafe|kafe|kopi|coffee|bakso|mie|ayam|rumah makan|\brm\b|warung|warteg|padang|bakery|roti|pizza|burger|kfc|mcd)/],
    ["transport",/(spbu|pertamina|shell|bensin|pertalite|pertamax|parkir|tol\b|grab|gojek)/],["kesehatan",/(apotek|apotik|farma|klinik|obat|rumah sakit)/],
    ["tagihan",/(pln|listrik|telkom|indihome|pulsa|pdam|token)/],["hiburan",/(bioskop|cinema|xxi|cgv|tiket)/],["pendidikan",/(buku|gramedia|sekolah|kursus)/],
    ["belanja",/(indomaret|alfamart|alfamidi|supermarket|hypermart|superindo|giant|lottemart|transmart|minimarket|toko)/]];
  const category = (catMap.find(([,re]) => re.test(all)) || ["belanja"])[0];
  const method = /(gopay|ovo|dana\b|shopeepay|linkaja)/.test(all) ? "ewallet" : /(kartu kredit|credit|visa|master)/.test(all) ? "kartu" : /(debit|qris|transfer|edc)/.test(all) ? "bank" : /(tunai|cash)/.test(all) ? "tunai" : null;
  return {merchant, date, total, category, method, items};
}
async function readOCR(){
  const f = S.scanFile; if (!f) return;
  const btn = $("#readBtn"), pv = $("#pv"), er = $("#scanErr");
  btn.disabled = true; btn.innerHTML = `<span class="spin"></span>Menyiapkan pembaca…`; pv.classList.add("reading"); er.hidden = true;
  try{
    const text = await ocrText(f, p => { const b = $("#readBtn"); if (b) b.innerHTML = `<span class="spin"></span>Membaca struk… ${Math.round(p*100)}%`; });
    if (!$("#readBtn")) return;
    const d = parseReceipt(text);
    if (!(d.total > 0)) throw {code:"unreadable"};
    const date = d.date && d.date <= today() ? d.date : today();
    txForm({type:"out", amount:d.total, category:d.category, date, acc:allAcc().find(a=>a.type===d.method)?.id, note:d.merchant, items:d.items, scanned:true});
  }catch(e){
    if (!$("#readBtn")) return;
    pv.classList.remove("reading"); btn.disabled = false; btn.innerHTML = `${ic("receipt")}Coba lagi`;
    const msg = e && e.code==="unreadable" ? "Total belanja tidak ditemukan. Foto ulang lebih dekat, lurus, dan terang, atau isi manual."
      : "Pembaca struk gagal dimuat. Pastikan HP tersambung internet (dibutuhkan saat pertama kali), lalu coba lagi.";
    er.innerHTML = esc(msg) + ` <button type="button" class="link" data-act="newTx" data-type="out">Isi manual</button>`; er.hidden = false;
  }
}
