function fileBtn(id, cls, inner, capture){
  return `<div class="filebtn ${cls}">${inner}<input type="file" id="${id}" accept="image/*" ${capture?'capture="environment"':""} aria-label="${capture?"Ambil foto struk":"Pilih foto struk"}"></div>`;
}
const APP_URL = "https://claude.ai/artifact/CaFuJg5C1DUhaTXAQ39Xdf";
const inAndroidApp = (() => { const ua = navigator.userAgent || ""; return /Android/i.test(ua) && (/; wv\)/.test(ua) || /Claude/i.test(ua)); })();
function browserNotice(strong){
  return `<div class="notice ${strong?"strong":""}">
    <b>${strong?"Kamera belum bisa dibuka di aplikasi Claude Android":"Kamera atau galeri tidak terbuka?"}</b>
    <span>Aplikasi Claude di Android belum mengizinkan halaman ini membuka kamera atau galeri. Buka Financial Freedom lewat <b>Chrome</b> (masuk dengan akun Claude yang sama). Datamu tetap sama karena tersimpan di akunmu.</span>
    <div class="row2"><a class="btn block" href="${APP_URL}" target="_blank" rel="noopener">Buka di Chrome</a><button type="button" class="btn ghost block" data-act="copyLink">Salin tautan</button></div>
    <code class="applink">${APP_URL}</code>
  </div>`;
}
function scanSheet(){
  S.scanFile = null;
  openSheet("Scan struk", `<div class="form" id="scanBox">
    ${inAndroidApp ? browserNotice(true) : ""}
    ${fileBtn("scanCam","drop",`<span class="art">${ic("camera")}</span><b>Ambil foto struk</b><span style="font-size:13px">Letakkan struk di permukaan rata dengan cahaya cukup</span>`,true)}
    ${fileBtn("scanGal","btn ghost block",`${ic("receipt")}Pilih dari galeri`,false)}
    <div class="paste" id="pasteZone" contenteditable="true" role="textbox" aria-label="Tempel foto struk di sini" inputmode="none" data-ph="Atau salin foto struk dari Galeri, lalu tekan lama di sini dan pilih Tempel"></div>
    <button type="button" class="link" data-act="newTx" data-type="out" style="justify-self:center">Isi manual tanpa foto</button>
    <p class="hint" id="scanHint">Memeriksa fitur baca otomatis…</p>
    ${inAndroidApp || STANDALONE ? "" : browserNotice(false)}
  </div>`);
  scanStatus().then(st => { const h = $("#scanHint"); if (h) h.innerHTML = st.ok
    ? (STANDALONE ? "Struk dibaca langsung di HP-mu. Butuh internet saat pertama kali dipakai. Periksa hasilnya sebelum menyimpan." : "Claude akan membaca toko, tanggal, total, dan daftar item. Kamu bisa memeriksa hasilnya sebelum disimpan.")
    : esc(st.why) + " Kamu tetap bisa memakai foto sebagai acuan dan mengisi nominal sendiri."; });
}
async function scanStatus(){
  if (STANDALONE) return {ok:true, ocr:true};
  const s = S.sample || (S.samplePromise ? await S.samplePromise.catch(()=>null) : null);
  if (!s) return {ok:false, why:"Pembacaan otomatis tidak tersedia di tampilan ini (fitur Claude tidak aktif di sini). Coba buka aplikasi lewat claude.ai di browser HP."};
  try{ const l = await s.limits(); if (!l || !l.images) return {ok:false, why:"Tampilan ini belum bisa mengirim foto ke Claude. Coba buka lewat claude.ai di Chrome atau Safari."}; }
  catch(e){ return {ok:false, why:"Tidak bisa memeriksa fitur baca otomatis."}; }
  return {ok:true};
}
async function toJpeg(file){
  let src, w, h;
  try{ src = await createImageBitmap(file, {imageOrientation:"from-image"}); w = src.width; h = src.height; }
  catch(e){
    src = await new Promise((res, rej) => { const im = new Image(); const u = URL.createObjectURL(file); im.onload = () => res(im); im.onerror = () => rej(new Error("decode")); im.src = u; });
    w = src.naturalWidth; h = src.naturalHeight;
  }
  if (!w || !h) throw new Error("decode");
  const k = Math.min(1, 1800 / Math.max(w, h)); const c = document.createElement("canvas");
  c.width = Math.round(w*k); c.height = Math.round(h*k);
  const g = c.getContext("2d"); g.fillStyle = "#fff"; g.fillRect(0, 0, c.width, c.height); g.drawImage(src, 0, 0, c.width, c.height);
  return await new Promise((res, rej) => c.toBlob(b => b ? res(b) : rej(new Error("encode")), "image/jpeg", 0.85));
}
async function scanPreview(file){
  const box = $("#scanBox"); if (!box) return;
  box.innerHTML = `<div class="preview" id="pv" style="min-height:180px"><span class="hint" style="display:flex;gap:8px;align-items:center"><span class="spin"></span>Menyiapkan foto…</span></div>`;
  let jpg;
  try{ jpg = await toJpeg(file); }
  catch(e){
    if (!$("#scanBox")) return;
    $("#scanBox").innerHTML = `<p class="err">Foto tidak bisa dibuka (format seperti HEIC kadang tidak didukung). Pilih foto lain atau ubah format kamera ke JPG.</p>
      <div class="actions two"><button type="button" class="btn ghost" data-act="scan">Ulangi</button><button type="button" class="btn block" data-act="newTx" data-type="out">Isi manual</button></div>`;
    return;
  }
  if (!$("#scanBox")) return;
  S.scanFile = jpg; const url = URL.createObjectURL(jpg); const st = await scanStatus();
  $("#scanBox").innerHTML = `<div class="preview" id="pv"><img src="${url}" alt="Foto struk"></div>
    <p class="err" id="scanErr" ${st.ok?"hidden":""}>${st.ok?"":esc(st.why)}</p>
    <div class="actions two"><button type="button" class="btn ghost" data-act="scan">Ulangi</button>${st.ok
      ? `<button type="button" class="btn block" id="readBtn" data-act="readReceipt">${ic("receipt")}Baca struk</button>`
      : `<button type="button" class="btn block" data-act="newTx" data-type="out">Isi manual</button>`}</div>`;
}
