/* Android status bar: dark icons on the light theme, light icons on the dark theme */
function styleStatusBar(){
  const sb = plug("StatusBar"); if (!sb) return;
  const dark = (() => { try{ return matchMedia("(prefers-color-scheme: dark)").matches; }catch(e){ return false; } })();
  try{ sb.setOverlaysWebView({overlay:false}); }catch(e){}
  try{ sb.setStyle({style: dark ? "DARK" : "LIGHT"}); }catch(e){}
  try{ sb.setBackgroundColor({color: dark ? "#0B0F1E" : "#F2F3F8"}); }catch(e){}
}
styleStatusBar();
try{ matchMedia("(prefers-color-scheme: dark)").addEventListener("change", styleStatusBar); }catch(e){}

/* Android hardware back button inside the installed app */
if (plug("App")) plug("App").addListener("backButton", () => {
  if ($("#sheet").classList.contains("open")) closeSheet();
  else if (S.tab!=="home") go("home");
  else plug("App").exitApp();
});
