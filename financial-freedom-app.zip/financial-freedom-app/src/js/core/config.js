/* Replaced by build.py with the version from package.json and the build date. */
const APP_VERSION = "__APP_VERSION__";

/* ---------- reference data ---------- */
const OUT = [
  {id:"makan",n:"Makan & Minum",i:"food",c:"--c2"},
  {id:"transport",n:"Transportasi",i:"bus",c:"--c5"},
  {id:"belanja",n:"Belanja Harian",i:"bag",c:"--c4"},
  {id:"tagihan",n:"Tagihan & Pulsa",i:"bolt",c:"--c9"},
  {id:"rumah",n:"Rumah / Kos",i:"home",c:"--c1"},
  {id:"hiburan",n:"Hiburan",i:"play",c:"--c7"},
  {id:"kesehatan",n:"Kesehatan",i:"heart",c:"--c3"},
  {id:"pendidikan",n:"Pendidikan",i:"book",c:"--c8"},
  {id:"sedekah",n:"Sedekah & Zakat",i:"gift",c:"--c6"},
  {id:"lainnya",n:"Lainnya",i:"dots",c:"--c10"}
];
const IN = [
  {id:"gaji",n:"Gaji",i:"brief",c:"--c3"},
  {id:"thr",n:"Bonus & THR",i:"star",c:"--c9"},
  {id:"usaha",n:"Usaha",i:"store",c:"--c2"},
  {id:"freelance",n:"Freelance",i:"laptop",c:"--c5"},
  {id:"investasi",n:"Hasil Investasi",i:"trend",c:"--c1"},
  {id:"hadiah",n:"Hadiah / Kiriman",i:"gift",c:"--c4"},
  {id:"lainnya_in",n:"Lainnya",i:"dots",c:"--c10"}
];
const CAT = Object.fromEntries([...OUT,...IN].map(c=>[c.id,c]));
const LEGACY_METHODS = {tunai:"Tunai",bank:"Rekening Bank",ewallet:"E-wallet",kartu:"Kartu Kredit"};
const ACCTYPES = {
  tunai:{n:"Tunai",i:"cash",c:"--c3"},
  bank:{n:"Rekening Bank",i:"bank",c:"--c1"},
  ewallet:{n:"E-wallet",i:"phone",c:"--c5"},
  kartu:{n:"Kartu Kredit",i:"card",c:"--c4"},
  lainnya:{n:"Lainnya",i:"wallet",c:"--c10"}
};
const SVTYPES = {
  tunai:{n:"Tunai",i:"cash",c:"--c3"},
  bank:{n:"Deposito / Bank",i:"bank",c:"--c1"},
  emas:{n:"Emas",i:"gold",c:"--c6"},
  investasi:{n:"Investasi",i:"trend",c:"--c7"},
  lainnya:{n:"Lainnya",i:"dots",c:"--c10"}
};
