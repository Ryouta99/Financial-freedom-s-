/* ---------- storage ---------- */
function saveLocal(){ try{ localStorage.setItem(LKEY, JSON.stringify(Object.fromEntries(S.docs))); }catch(e){} }
function useLocal(){
  S.mode="local"; S.storageBad = !storageOK();
  try{ navigator.storage && navigator.storage.persist && navigator.storage.persist(); }catch(e){}
  try{ const raw = localStorage.getItem(LKEY) || localStorage.getItem(OLDKEY); if (raw) S.docs = new Map(Object.entries(JSON.parse(raw))); }catch(e){}
  S.ready=true; S.anim=true; render();
}
async function put(id, data){
  S.docs.set(id, data); render();
  if (S.mode==="cloud"){ try{ await S.col.doc(id).set(data); }catch(e){ toast(e&&e.code==="quota_exceeded" ? "Penyimpanan penuh. Hapus beberapa catatan lama." : "Gagal menyimpan. Periksa koneksi lalu coba lagi."); } }
  else saveLocal();
}
async function del(id){
  S.docs.delete(id); render();
  if (S.mode==="cloud"){ try{ await S.col.doc(id).delete(); }catch(e){ toast("Gagal menghapus. Coba lagi."); } }
  else saveLocal();
}

/* render scheduling: never swap the DOM under a finger that is pressing a button */
let pressing = false, pendingRender = false;
document.addEventListener("pointerdown", () => { pressing = true; }, true);
const release = () => { pressing = false; if (pendingRender){ pendingRender = false; setTimeout(render, 0); } };
document.addEventListener("pointerup", () => setTimeout(release, 30), true);
document.addEventListener("pointercancel", release, true);
function scheduleRender(){ if (pressing) pendingRender = true; else render(); }
