/* ---------- state ---------- */
const HKEY = "ff-hide-balance";
const S = { hide:(()=>{ try{ return localStorage.getItem(HKEY)==="1"; }catch(e){ return false; } })(), docs:new Map(), ready:false, mode:"loading", col:null, month:ymOf(new Date()), tab:"home", assetView:"acc",
  statType:"out", filter:"all", accFilter:"", q:"", sample:null, dl:null, scanFile:null, draft:null };
const LKEY = "financial-freedom-local-v1", OLDKEY = "dompet-saku-local-v1";

const allOf = kind => { const r=[]; S.docs.forEach((v,k)=>{ if(v&&v.kind===kind) r.push({...v,id:k}); }); return r; };
const allTx = () => allOf("tx").sort((a,b)=> (b.date||"").localeCompare(a.date||"") || (b.ts||0)-(a.ts||0));
const allSv = () => allOf("sv").sort((a,b)=>(a.ts||0)-(b.ts||0));
const allAcc = () => allOf("acc").sort((a,b)=>(a.ts||0)-(b.ts||0));
const settings = () => S.docs.get("settings") || {};
const svValue = s => s.type==="emas" ? (s.bal||0) * (settings().goldPrice||0) : (s.bal||0);
const monthTx = (ym, type) => allTx().filter(t => (t.date||"").startsWith(ym) && (type ? t.type===type : t.type!=="tf"));
const sum = arr => arr.reduce((a,t)=>a+(t.amount||0),0);
const hasDemo = () => { for (const v of S.docs.values()) if (v&&v.demo) return true; return false; };
function accBalance(id){
  const a = S.docs.get(id); let b = a ? (a.init||0) : 0;
  S.docs.forEach(t => { if (!t || t.kind!=="tx") return;
    if (t.type==="in" && t.acc===id) b += t.amount||0;
    else if (t.type==="out" && t.acc===id) b -= t.amount||0;
    else if (t.type==="tf"){ if (t.acc===id) b -= t.amount||0; if (t.to===id) b += t.amount||0; } });
  return b;
}
const accFlow = (id, ym) => { let i=0,o=0; allTx().forEach(t => { if (!(t.date||"").startsWith(ym)) return;
  if (t.type==="in"&&t.acc===id) i+=t.amount; else if (t.type==="out"&&t.acc===id) o+=t.amount;
  else if (t.type==="tf"){ if (t.to===id) i+=t.amount; if (t.acc===id) o+=t.amount; } }); return {i,o}; };
const endName = ref => { if (!ref) return "Tanpa rekening"; if (ref.startsWith("sv:")){ const s=S.docs.get(ref.slice(3)); return s ? (/^tabungan\b/i.test(s.name) ? s.name : "Tabungan " + s.name) : "Tabungan terhapus"; }
  const a = S.docs.get(ref); return a ? a.name : "Rekening terhapus"; };
const touchesAcc = (t, id) => t.acc===id || t.to===id;
