function viewAssets(){
  const accs = allAcc(), svs = allSv();
  const accTotal = accs.reduce((a,x)=>a+accBalance(x.id),0), svTotal = svs.reduce((a,s)=>a+svValue(s),0);
  const head = `${demoBanner()}<div class="card worth"><small style="color:var(--muted)">Kekayaan bersih</small><div class="v num ${accTotal+svTotal<0?"neg":""}" data-priv="1" data-count="${accTotal+svTotal}">${hid(accTotal+svTotal)}</div>
    <div class="sub"><span>Saldo rekening<b class="num">${hid(accTotal)}</b></span><span>Tabungan & aset<b class="num">${hid(svTotal)}</b></span></div></div>
    <div class="seg sec" style="margin-top:14px"><button type="button" data-act="assetView" data-v="acc" class="${S.assetView==="acc"?"on":""}">Rekening</button><button type="button" data-act="assetView" data-v="sv" class="${S.assetView==="sv"?"on":""}">Tabungan & Emas</button></div>`;
  if (S.assetView==="acc"){
    const ym = ymOf(new Date());
    return head + `<div class="sec"><div class="sec-h"><h2>Rekening</h2><button type="button" class="link" data-act="newAcc">+ Tambah</button></div>
      ${accs.length?`<div class="list">${accs.map(a=>{ const b=accBalance(a.id), f=accFlow(a.id,ym), t=ACCTYPES[a.type]||ACCTYPES.lainnya;
        return `<button type="button" class="acc-row" data-act="openAcc" data-id="${esc(a.id)}">${typeIcon(ACCTYPES,a.type)}<span class="meta"><b>${esc(a.name)}${a.demo?'<span class="badge">contoh</span>':""}</b><small>${esc(t.n)}${a.no?" · •••• "+esc(a.no):""}</small><small class="num">Bulan ini: +${HS(f.i)} / −${fmtShort(f.o)}</small></span><span class="val num ${b<0?"neg":""}">${hid(b)}${a.type==="kartu"&&b<0?"<small>tagihan</small>":""}</span></button>`; }).join("")}</div>
      <button type="button" class="btn ghost block" style="margin-top:12px" data-act="newTx" data-type="tf">${ic("swap")}Transfer antar rekening</button>`
      : `<div class="card empty"><div class="art">${ic("bank")}</div><h3>Belum ada rekening</h3><p>Tambah rekening bank, e-wallet, kartu kredit, atau dompet tunai supaya setiap transaksi bisa ditelusuri asalnya.</p><button type="button" class="btn" data-act="newAcc">${ic("plus")}Tambah rekening</button></div>`}</div>`;
  }
  const gp = settings().goldPrice||0;
  const byType = {}; svs.forEach(s => byType[s.type]=(byType[s.type]||0)+svValue(s));
  const grams = svs.filter(s=>s.type==="emas").reduce((a,s)=>a+(s.bal||0),0);
  const alloc = Object.entries(byType).filter(([,v])=>v>0).sort((a,b)=>b[1]-a[1]);
  return head + `${alloc.length?`<div class="sec card"><small style="color:var(--muted)">Komposisi tabungan</small><div class="stack">${alloc.map(([k,v])=>`<i style="width:${v/svTotal*100}%;background:var(${(SVTYPES[k]||SVTYPES.lainnya).c})"></i>`).join("")}</div>
    <div class="alloc">${alloc.map(([k,v])=>`<span><i style="background:var(${(SVTYPES[k]||SVTYPES.lainnya).c})"></i>${(SVTYPES[k]||SVTYPES.lainnya).n} ${Math.round(v/svTotal*100)}%</span>`).join("")}</div></div>`:""}
  <div class="sec goldcard"><span class="g">${ic("gold")}</span><span style="min-width:0"><small>Emas · ${HG(grams)}</small><b class="num">${gp?hid(grams*gp):"Harga belum diatur"}</b><small>${gp?`${rp(gp)} / gram`:"Isi harga per gram agar nilai emas terhitung"}</small></span>
    <button type="button" data-act="goldPrice">${gp?"Ubah harga":"Atur harga"}</button></div>
  <div class="sec"><div class="sec-h"><h2>Pos tabungan</h2><button type="button" class="link" data-act="newSv">+ Tambah</button></div>
    ${svs.length ? `<div class="list">${svs.map(svRow).join("")}</div>` :
    `<div class="card empty"><div class="art">${ic("gold")}</div><h3>Belum ada tabungan</h3><p>Catat dana darurat, emas batangan, deposito, atau investasi lain di satu tempat.</p><button type="button" class="btn" data-act="newSv">${ic("plus")}Tambah pos tabungan</button></div>`}
  </div>`;
}
function svRow(s){
  const t = SVTYPES[s.type]||SVTYPES.lainnya, val = svValue(s), gp = settings().goldPrice;
  const pct = s.target>0 ? Math.min(100, val/s.target*100) : null;
  return `<button type="button" class="sv" data-act="openSv" data-id="${esc(s.id)}">${typeIcon(SVTYPES,s.type)}
    <span class="meta"><b>${esc(s.name)}${s.demo?'<span class="badge">contoh</span>':""}</b><small>${t.n}${pct!==null?` · target ${hid(s.target)}`:""}</small></span>
    <span class="val num">${s.type==="emas"?(gp?hid(val):HG(s.bal)):hid(val)}${s.type==="emas"&&gp?`<small>${HG(s.bal)}</small>`:pct!==null?`<small>${Math.round(pct)}%</small>`:""}</span>
    ${pct!==null?`<span class="bar"><i style="width:${pct}%;background:var(${t.c})"></i></span>`:""}</button>`;
}
