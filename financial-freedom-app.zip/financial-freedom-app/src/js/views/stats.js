function donut(rows, total, priv){
  const r=54, C=2*Math.PI*r; let acc=0;
  const segs = rows.map(x => { const len = total? x.v/total*C : 0; const g = len>4?2:0;
    const s = `<circle class="donut-seg" cx="75" cy="75" r="${r}" fill="none" stroke="var(${x.c})" stroke-width="20" stroke-dasharray="${Math.max(0,len-g)} ${C}" stroke-dashoffset="${-acc}" transform="rotate(-90 75 75)"/>`; acc+=len; return s; }).join("");
  return `<svg viewBox="0 0 150 150" role="img" aria-label="Komposisi per kategori"><circle cx="75" cy="75" r="${r}" fill="none" stroke="var(--surface2)" stroke-width="20"/>${segs}
    <text x="75" y="70" text-anchor="middle" style="font:600 10px var(--body);fill:var(--muted)">Total</text>
    <text x="75" y="88" text-anchor="middle" style="font:800 16px var(--display);fill:var(--fg)">${priv?HS(total):fmtShort(total)}</text></svg>`;
}
function niceTop(mx){ const p = Math.pow(10, Math.floor(Math.log10(mx))); for (const m of [1,2,2.5,5,10]) if (m*p >= mx) return m*p; return 10*p; }
function barsChart(){
  const months = [...Array(6)].map((_,i)=>addMonth(S.month,i-5));
  const data = months.map(m=>({m, i:sum(monthTx(m,"in")), o:sum(monthTx(m,"out"))}));
  const top = niceTop(Math.max(1,...data.map(d=>S.hide ? d.o : Math.max(d.i,d.o))));
  const W=340,H=180,L=42,R=6,T=10,B=24, ph=H-T-B, gw=(W-L-R)/6, bw=Math.min(14,gw/3.2);
  const y = v => T + ph - v/top*ph;
  let g = "";
  [0, top/2, top].forEach(v => { g += `<line x1="${L}" x2="${W-R}" y1="${y(v)}" y2="${y(v)}" stroke="var(--line)" stroke-dasharray="${v?"3 4":""}"/><text x="${L-6}" y="${y(v)+3.5}" text-anchor="end">${fmtShort(v)}</text>`; });
  data.forEach((d,k) => { const cx = L + gw*k + gw/2; const cur = d.m===S.month; const op = t => (S.statType===t?1:.35);
    if (!S.hide) g += `<rect x="${cx-bw-1.5}" y="${y(d.i)}" width="${bw}" height="${Math.max(0,ph+T-y(d.i))}" rx="4" fill="var(--in)" style="--d:${k}" opacity="${op("in")}"><title>Pemasukan ${monthName(d.m)}: ${rp(d.i)}</title></rect>`;
    g += `<rect x="${cx+1.5}" y="${y(d.o)}" width="${bw}" height="${Math.max(0,ph+T-y(d.o))}" rx="4" fill="var(--out)" style="--d:${k}" opacity="${op("out")}"><title>Pengeluaran ${monthName(d.m)}: ${rp(d.o)}</title></rect>`;
    g += `<text x="${cx}" y="${H-7}" text-anchor="middle" style="${cur?"fill:var(--fg);font-weight:700":""}">${monthShort(d.m)}</text>`; });
  return `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Pemasukan dan pengeluaran 6 bulan terakhir">${g}</svg>`;
}
function dailyChart(type){
  const n = daysIn(S.month), arr = Array(n).fill(0);
  monthTx(S.month,type).forEach(t => { arr[Number(t.date.slice(8))-1] += t.amount; });
  const mx = Math.max(1,...arr), W=340,H=110,L=6,R=6,T=8,B=18, ph=H-T-B, bw=(W-L-R)/n;
  const col = type==="in"?"var(--in)":"var(--out)";
  let g = `<line x1="${L}" x2="${W-R}" y1="${T+ph}" y2="${T+ph}" stroke="var(--line)"/>`;
  arr.forEach((v,i) => { const h = v/mx*ph; if (v>0) g += `<rect x="${L+i*bw+1}" y="${T+ph-h}" width="${Math.max(1,bw-2)}" height="${h}" rx="2" fill="${col}"><title>Tgl ${i+1}: ${type==="in"?hid(v):rp(v)}</title></rect>`;
    if ([0,9,19,n-1].includes(i)) g += `<text x="${L+i*bw+bw/2}" y="${H-5}" text-anchor="middle">${i+1}</text>`; });
  return `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Per hari">${g}</svg>`;
}
function viewStats(){
  const type = S.statType, list = monthTx(S.month,type), total = sum(list), prev = sum(monthTx(addMonth(S.month,-1),type));
  const by = {}; list.forEach(t => by[t.category]=(by[t.category]||0)+t.amount);
  const rows = Object.entries(by).map(([k,v])=>({k, v, c:(CAT[k]||CAT.lainnya).c, n:(CAT[k]||CAT.lainnya).n})).sort((a,b)=>b.v-a.v);
  const byAcc = {}; list.forEach(t => { const k=t.acc||""; byAcc[k]=(byAcc[k]||0)+t.amount; });
  const accRows = Object.entries(byAcc).sort((a,b)=>b[1]-a[1]);
  let chip = `<span class="chip neutral">Bulan lalu ${type==="in"?hid(prev):rp(prev)}</span>`;
  if (prev>0 && total>0){ const d = (total-prev)/prev*100; const good = type==="out" ? d<=0 : d>=0;
    chip = `<span class="chip ${good?"good":"bad"}">${d>=0?"▲":"▼"} ${Math.abs(Math.round(d))}% vs bulan lalu</span>`; }
  const now = new Date(); const daysPassed = S.month===ymOf(now) ? now.getDate() : daysIn(S.month);
  const biggest = list.slice().sort((a,b)=>b.amount-a.amount)[0];
  const tin = sum(monthTx(S.month,"in")), tout = sum(monthTx(S.month,"out"));
  const rate = tin>0 ? Math.round((tin-tout)/tin*100) : null;
  return `${demoBanner()}${monthBar()}
  <div class="seg"><button type="button" data-act="statType" data-t="out" class="${type==="out"?"on":""}">Pengeluaran</button><button type="button" data-act="statType" data-t="in" class="${type==="in"?"on":""}">Pemasukan</button></div>
  <div class="sec card"><div class="stat-top"><small style="color:var(--muted)">Total ${type==="out"?"pengeluaran":"pemasukan"}</small><div class="v num" ${type==="in"?'data-priv="1"':""} data-count="${total}">${type==="in"?hid(total):rp(total)}</div></div><div style="margin-top:8px">${chip}</div>
    ${rows.length ? `<div class="donut-wrap" style="margin-top:16px">${donut(rows,total,type==="in")}<div class="legend">${rows.slice(0,6).map(r=>`<div class="lg"><i style="background:var(${r.c})"></i><span>${esc(r.n)}</span><b class="num">${Math.round(r.v/total*100)}%</b></div>`).join("")}</div></div>`
      : `<div class="empty"><p>Belum ada ${type==="out"?"pengeluaran":"pemasukan"} di bulan ini.</p></div>`}
  </div>
  <div class="sec insights">
    <div class="insight"><small>Rata-rata / hari</small><b class="num">${(type==="in"?hid:rp)(total/Math.max(1,daysPassed))}</b></div>
    <div class="insight"><small>${type==="out"?"Porsi ditabung":"Sumber utama"}</small><b class="num">${type==="out" ? (rate===null?"—":rate+"% dari pemasukan") : esc(rows[0]?.n||"—")}</b></div>
    <div class="insight" style="grid-column:1/-1"><small>Transaksi terbesar</small><b>${biggest?`${(type==="in"?hid:rp)(biggest.amount)} · ${esc(biggest.note||CAT[biggest.category]?.n||"")}`:"—"}</b></div>
  </div>
  <div class="sec card chart"><div class="sec-h"><h2>6 bulan terakhir</h2></div>${barsChart()}
    <div class="chart-legend"><span><i style="background:var(--in)"></i>Pemasukan${S.hide?" (disembunyikan)":""}</span><span><i style="background:var(--out)"></i>Pengeluaran</span></div></div>
  <div class="sec card chart"><div class="sec-h"><h2>Per hari</h2><small style="color:var(--muted)">${esc(monthName(S.month))}</small></div>${dailyChart(type)}</div>
  ${accRows.length?`<div class="sec card"><div class="sec-h"><h2>${type==="out"?"Keluar dari":"Masuk ke"} rekening</h2></div><div class="cat-rows">${accRows.map(([k,v])=>{ const a=S.docs.get(k); const t=ACCTYPES[a?.type]||ACCTYPES.lainnya;
      return `<div class="cat-row" style="--cc:var(${t.c})">${typeIcon(ACCTYPES,a?.type)}<div><div class="t"><span>${esc(endName(k))}</span><span class="num">${(type==="in"?hid:rp)(v)}</span></div><div class="bar"><i style="width:${v/accRows[0][1]*100}%"></i></div></div></div>`; }).join("")}</div></div>`:""}
  ${rows.length?`<div class="sec card"><div class="sec-h"><h2>Rincian kategori</h2></div><div class="cat-rows">${rows.map(r=>{ const inner = `${catIcon(r.k)}<div><div class="t"><span>${esc(r.n)}</span><span class="num">${(type==="in"?hid:rp)(r.v)}</span></div><div class="bar"><i style="width:${r.v/rows[0].v*100}%"></i></div></div>`;
      return type==="out" ? `<button type="button" class="cat-row" data-act="openCat" data-id="${r.k}" style="--cc:var(${r.c})">${inner}</button>` : `<div class="cat-row" style="--cc:var(${r.c})">${inner}</div>`; }).join("")}</div></div>`:""}`;
}
