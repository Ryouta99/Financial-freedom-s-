function txRow(t, ctxAcc){
  if (t.type==="tf"){
    let sign = "", cls = "tf";
    if (ctxAcc){ if (t.acc===ctxAcc){ sign="−"; cls="out"; } else if (t.to===ctxAcc){ sign="+"; cls="in"; } }
    return `<button type="button" class="tx" data-act="editTx" data-id="${esc(t.id)}"><span class="qi tf" style="width:42px;height:42px;border-radius:14px">${ic("swap")}</span>
      <span class="meta"><b>${esc(t.note || "Transfer")}</b><small>${esc(endName(t.acc))} → ${esc(endName(t.to))}</small></span>
      <span class="amt num ${cls}">${S.hide?"":sign}${hid(t.amount)}</span></button>`;
  }
  const c = CAT[t.category] || CAT.lainnya;
  const src = t.acc ? endName(t.acc) : (LEGACY_METHODS[t.method] || "Tanpa rekening");
  return `<button type="button" class="tx" data-act="editTx" data-id="${esc(t.id)}">${catIcon(t.category)}
    <span class="meta"><b>${esc(t.note || c.n)}${t.scanned?'<span class="badge">struk</span>':""}</b><small>${t.note?esc(c.n)+" · ":""}${esc(src)}</small></span>
    <span class="amt num ${t.type}">${t.type==="in"?(S.hide?"":"+")+hid(t.amount):"−"+rp(t.amount)}</span></button>`;
}
function accCard(a){
  const b = accBalance(a.id); const t = ACCTYPES[a.type]||ACCTYPES.lainnya;
  return `<button type="button" class="acc-card" data-act="openAcc" data-id="${esc(a.id)}"><span class="top2">${typeIcon(ACCTYPES,a.type)}<span class="no">${a.no?"•••• "+esc(a.no):esc(t.n)}</span></span>
    <span style="min-width:0"><span class="nm" style="display:block">${esc(a.name)}</span><span class="bl num ${b<0?"neg":""}" style="display:block">${hid(b)}</span></span></button>`;
}

function viewHome(){
  const tin = sum(monthTx(S.month,"in")), tout = sum(monthTx(S.month,"out"));
  const recent = allTx().filter(t=>(t.date||"").startsWith(S.month)).slice(0,6);
  const st = settings(); const budget = st.budget||0;
  const accs = allAcc();
  const empty = allTx().length===0 && allSv().length===0 && accs.length===0;
  let budgetHTML;
  if (budget>0){ const pct = Math.min(100, tout/budget*100); const left = budget - tout;
    const now=new Date(); const dLeft = S.month===ymOf(now) ? daysIn(S.month)-now.getDate()+1 : 0;
    budgetHTML = `<button type="button" class="card budget" data-act="settings" style="width:100%;border:0;text-align:left;color:var(--fg)"><div class="row"><span>Anggaran bulanan</span><span class="num"><b>${rp(tout)}</b> / ${rp(budget)}</span></div>
      <div class="bar ${pct>=100?"over":pct>=80?"warn":""}"><i style="width:${pct}%"></i></div>
      <div class="row" style="margin-top:8px"><span>${left>=0?`Sisa ${rp(left)}`:`Lewat ${rp(-left)}`}</span><span>${dLeft>0&&left>0?`± ${rp(left/dLeft)} / hari`:`${Math.round(tout/budget*100)}% terpakai`}</span></div></button>`;
  } else budgetHTML = `<button type="button" class="card rowcard" data-act="settings"><span class="qi scan">${ic("target")}</span><span class="grow"><b style="display:block">Atur anggaran bulanan</b><small>Pantau sisa uang belanja tiap hari</small></span>${ic("chevR")}</button>`;

  return `${demoBanner()}${backupReminder()}${monthBar()}
  <section class="hero" aria-label="Ringkasan bulan ini">
    <div><div class="lbl" style="display:flex;justify-content:space-between;align-items:center;gap:8px"><span>Selisih ${esc(monthName(S.month))}</span><button type="button" class="hero-eye" data-act="toggleHide" aria-label="${S.hide?"Tampilkan saldo":"Sembunyikan saldo"}">${ic(S.hide?"eyeOff":"eye")}${S.hide?"Tampilkan":"Sembunyikan"}</button></div><div class="big num" data-priv="1" data-count="${tin-tout}">${hid(tin-tout)}</div></div>
    <div class="split">
      <div class="pill"><span class="dot in">${ic("inArr")}</span><span style="min-width:0"><small>Pemasukan</small><b class="num">${hid(tin)}</b></span></div>
      <div class="pill"><span class="dot out">${ic("outArr")}</span><span style="min-width:0"><small>Pengeluaran</small><b class="num">${rp(tout)}</b></span></div>
    </div>
  </section>
  <div class="quick">
    <button type="button" data-act="newTx" data-type="out"><span class="qi out">${ic("outArr")}</span>Keluar</button>
    <button type="button" data-act="newTx" data-type="in"><span class="qi in">${ic("inArr")}</span>Masuk</button>
    <button type="button" data-act="newTx" data-type="tf"><span class="qi tf">${ic("swap")}</span>Transfer</button>
    <button type="button" data-act="scan"><span class="qi scan">${ic("camera")}</span>Scan struk</button>
  </div>
  <div class="sec"><div class="sec-h"><h2>Rekening</h2><button type="button" class="link" data-act="goAssets" data-v="acc">Kelola</button></div>
    <div class="acc-strip">${accs.map(accCard).join("")}<button type="button" class="acc-card add" data-act="newAcc">${ic("plus")}Tambah rekening</button></div></div>
  <div class="sec" style="margin-top:12px">${budgetHTML}</div>
  ${categoryCard()}
  <div class="sec"><div class="sec-h"><h2>Transaksi terbaru</h2>${recent.length?`<button type="button" class="link" data-act="tab" data-tab="tx">Lihat semua</button>`:""}</div>
    ${empty ? emptyState() : recent.length ? `<div class="card tx-list" style="padding:6px 8px">${recent.map(t=>txRow(t)).join("")}</div>`
      : `<div class="card empty"><p>Belum ada transaksi di ${esc(monthName(S.month))}.</p><button type="button" class="btn" data-act="add">${ic("plus")}Catat sekarang</button></div>`}
  </div>`;
}
function emptyState(){
  return `<div class="card empty"><div class="art">${ic("wallet")}</div><h3>Mulai dari rekeningmu</h3>
  <p>Tambahkan rekening bank, e-wallet, atau dompet tunai. Setiap pemasukan dan pengeluaran akan tercatat dari rekening mana.</p>
  <div style="display:grid;gap:8px;width:100%;margin-top:8px"><button type="button" class="btn block" data-act="newAcc">${ic("plus")}Tambah rekening pertama</button>
  <button type="button" class="btn ghost block" data-act="loadDemo">Coba dengan data contoh</button></div></div>`;
}
