function txListHTML(){
  let list = allTx().filter(t=>(t.date||"").startsWith(S.month));
  if (S.filter!=="all") list = list.filter(t=>t.type===S.filter);
  if (S.accFilter) list = list.filter(t=>touchesAcc(t,S.accFilter));
  const q = S.q.trim().toLowerCase();
  if (q) list = list.filter(t => (t.note||"").toLowerCase().includes(q) || (CAT[t.category]?.n||"").toLowerCase().includes(q) || endName(t.acc).toLowerCase().includes(q) || (t.items||[]).some(i=>(i.name||"").toLowerCase().includes(q)));
  const groups = {}; list.forEach(t => (groups[t.date] ||= []).push(t));
  if (!list.length) return `<div class="empty"><p>${q||S.accFilter||S.filter!=="all"?"Tidak ada transaksi yang cocok.":"Belum ada transaksi bulan ini."}</p></div>`;
  return Object.keys(groups).sort().reverse().map(d => {
    const net = groups[d].reduce((a,t)=>{ if (t.type==="in") return a+t.amount; if (t.type==="out") return a-t.amount;
      if (S.accFilter){ if (t.to===S.accFilter) return a+t.amount; if (t.acc===S.accFilter) return a-t.amount; } return a; },0);
    return `<div class="day-h"><span>${esc(dayLabel(d))}</span><span class="num">${S.hide&&groups[d].some(t=>t.type!=="out") ? hid(net) : (net>0?"+":"")+rp(net)}</span></div>${groups[d].map(t=>txRow(t,S.accFilter)).join("")}`; }).join("");
}
function viewTx(){
  const accs = allAcc(); const fa = S.accFilter && S.docs.get(S.accFilter);
  return `${demoBanner()}${monthBar()}
  <div class="filters">
    <div class="seg">${[["all","Semua"],["out","Keluar"],["in","Masuk"],["tf","Transfer"]].map(([k,l])=>`<button type="button" data-act="filter" data-f="${k}" class="${S.filter===k?"on":""}">${l}</button>`).join("")}</div>
    <div class="row2"><select class="inp" id="accFilter" aria-label="Filter rekening"><option value="">Semua rekening</option>${accs.map(a=>`<option value="${esc(a.id)}" ${S.accFilter===a.id?"selected":""}>${esc(a.name)}</option>`).join("")}</select>
    <label class="search">${ic("search")}<input id="q" type="search" placeholder="Cari…" value="${esc(S.q)}" aria-label="Cari transaksi"></label></div>
    ${fa?`<div class="trace">${ic("bank")}<span>Menelusuri <b>${esc(fa.name)}</b> · saldo ${hid(accBalance(S.accFilter))}</span><button type="button" data-act="clearAccFilter">Lepas</button></div>`:""}
  </div>
  <div class="card tx-list" id="txBody" style="padding:0 8px 8px;margin-top:12px">${txListHTML()}</div>`;
}
