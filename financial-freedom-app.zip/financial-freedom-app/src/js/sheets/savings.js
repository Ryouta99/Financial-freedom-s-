function svForm(s){
  const type = s.type||"bank";
  openSheet(s.id?"Ubah pos tabungan":"Pos tabungan baru", `<form id="svForm" class="form" novalidate>
    <input type="hidden" name="rid" value="${esc(s.id||"")}">
    <div><div class="lbl">Jenis</div><div class="chips">${Object.entries(SVTYPES).map(([k,t])=>`<label style="--cc:var(${t.c})"><input type="radio" name="type" value="${k}" ${k===type?"checked":""}><span><span class="cat-ic">${ic(t.i)}</span>${t.n}</span></label>`).join("")}</div></div>
    <div><div class="lbl">Nama</div><input class="inp" id="sName" name="name" maxlength="40" placeholder="mis. Dana darurat, Antam 5 gram" value="${esc(s.name||"")}"></div>
    <div id="balWrap">${balField(type, s.bal)}</div>
    <div><div class="lbl">Target (opsional)</div><input class="inp" id="sTarget" name="target" inputmode="numeric" data-money placeholder="Rp 0" value="${s.target?fmtNum(s.target):""}"></div>
    <p class="err" id="svErr" hidden></p>
    <div class="actions ${s.id?"two":""}">${s.id?`<button type="button" class="btn danger" data-act="delSv" data-id="${esc(s.id)}" aria-label="Hapus pos">${ic("trash")}</button>`:""}<button class="btn block" type="submit">Simpan</button></div>
  </form>`);
}
const balField = (type, bal) => type==="emas"
  ? `<div class="lbl">Berat emas saat ini (gram)</div><input class="inp" id="sBal" name="bal" inputmode="decimal" placeholder="mis. 5 atau 2,5" value="${bal?String(bal).replace(".",","):""}">`
  : `<div class="lbl">Saldo saat ini</div><input class="inp" id="sBal" name="bal" inputmode="numeric" data-money placeholder="Rp 0" value="${bal?fmtNum(bal):""}">`;

function svDetail(id){
  const s = S.docs.get(id); if (!s) return; const t = SVTYPES[s.type]||SVTYPES.lainnya; const gold = s.type==="emas";
  const hist = (s.hist||[]).slice().reverse();
  openSheet(s.name, `<div class="form">
    <div class="card" style="box-shadow:none;background:var(--surface2)"><small style="color:var(--muted)">${t.n}</small>
      <div style="font:800 28px var(--display);letter-spacing:-.02em" class="num">${gold?HG(s.bal):hid(s.bal)}</div>
      ${gold?`<small style="color:var(--muted)">${settings().goldPrice?`≈ ${hid(svValue(s))}`:"Atur harga emas untuk melihat nilainya"}</small>`:""}
      ${s.target>0?`<div class="bar" style="margin-top:10px"><i style="width:${Math.min(100,svValue(s)/s.target*100)}%;background:var(${t.c})"></i></div><small style="color:var(--muted)">${Math.round(svValue(s)/s.target*100)}% dari target ${hid(s.target)}</small>`:""}
    </div>
    <form id="moveForm" class="form" novalidate><input type="hidden" name="rid" value="${esc(id)}">
      <div class="seg"><label><input type="radio" name="dir" value="1" checked><span>Setor</span></label><label><input type="radio" name="dir" value="-1"><span>Tarik</span></label></div>
      ${gold?`<div class="row2"><div><div class="lbl">Berat (gram)</div><input class="inp" id="mAmt" name="amt" inputmode="decimal" placeholder="mis. 1 atau 0,5"></div><div><div class="lbl">Nominal Rp</div><input class="inp" id="mRp" name="rp" inputmode="numeric" data-money placeholder="harga beli/jual"></div></div>`
        :`<div><div class="lbl">Jumlah</div><input class="inp" id="mAmt" name="amt" inputmode="numeric" data-money placeholder="Rp 0"></div>`}
      <div><div class="lbl" id="mAccLbl">Ambil dana dari rekening</div><select class="inp" id="mAcc" name="acc">${accOptions("", {none:"Tidak lewat rekening"})}</select></div>
      <input class="inp" id="mNote" name="note" maxlength="40" placeholder="Keterangan (opsional)" aria-label="Keterangan">
      <p class="err" id="mvErr" hidden></p>
      <div class="actions two"><button type="button" class="btn ghost" data-act="editSv" data-id="${esc(id)}">Ubah</button><button class="btn block" type="submit">Simpan</button></div>
    </form>
    <div><div class="lbl">Riwayat</div>${hist.length?`<div class="hist">${hist.map(h=>`<div><span>${esc(dayLabel(h.d))}${h.n?" · "+esc(h.n):""}</span><b class="num" style="color:${h.a>=0?"var(--in)":"var(--out)"}">${h.a>=0?"+":"−"}${gold?HG(Math.abs(h.a)):hid(Math.abs(h.a))}</b></div>`).join("")}</div>`:`<p class="hint">Belum ada setoran atau penarikan.</p>`}</div>
  </div>`);
}
