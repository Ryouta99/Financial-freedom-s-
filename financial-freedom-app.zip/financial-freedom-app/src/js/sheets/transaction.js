function catChips(type, sel){
  const list = type==="in"?IN:OUT; sel = sel && list.some(c=>c.id===sel) ? sel : list[0].id;
  return list.map(c=>`<label style="--cc:var(${c.c})"><input type="radio" name="cat" value="${c.id}" ${c.id===sel?"checked":""}><span>${catIcon(c.id)}${esc(c.n)}</span></label>`).join("");
}
function accOptions(sel, opts={}){
  const accs = allAcc();
  if (!accs.length && !opts.none) return `<option value="__auto">Dompet Tunai (dibuat otomatis)</option>`;
  let h = opts.none ? `<option value="">${esc(opts.none)}</option>` : "";
  if (opts.sv) h += allSv().map(s=>`<option value="sv:${esc(s.id)}" ${sel==="sv:"+s.id?"selected":""}>Tabungan · ${esc(s.name)}</option>`).join("");
  h += accs.map(a=>`<option value="${esc(a.id)}" ${sel===a.id?"selected":""}>${esc(a.name)} · ${hid(accBalance(a.id))}</option>`).join("");
  return h;
}
function txFields(t){
  const type = t.type||"out";
  if (type==="tf"){
    const accs = allAcc(); const from = t.acc || accs[0]?.id || ""; const to = t.to || accs.find(a=>a.id!==from)?.id || "";
    return `${accs.length<2?`<p class="hint">Transfer butuh minimal dua rekening. <button type="button" class="link" data-act="newAccInline">+ Tambah rekening</button></p>`:""}
    <div class="swap"><div><div class="lbl">Dari</div><select class="inp" id="fAcc" name="acc">${accOptions(from)}</select></div>
      <span class="arrow">${ic("arrowR")}</span>
      <div><div class="lbl">Ke</div><select class="inp" id="fTo" name="to">${accOptions(to)}</select></div></div>
    <div class="row2"><div><div class="lbl">Tanggal</div><input class="inp" type="date" id="fDate" name="date" value="${esc(t.date||today())}" max="${today()}"></div>
      <div><div class="lbl">Biaya admin</div><input class="inp" id="fFee" name="fee" inputmode="numeric" data-money placeholder="Rp 0" value="${t.fee?fmtNum(t.fee):""}"></div></div>
    <div><div class="lbl">Catatan</div><input class="inp" id="fNote" name="note" maxlength="80" placeholder="mis. Tarik tunai ATM, isi saldo e-wallet" value="${esc(t.note||"")}"></div>`;
  }
  return `<div><div class="lbl">Kategori</div><div class="chips" id="catChips">${catChips(type,t.category)}</div></div>
    <div><div class="lbl"><span>${type==="in"?"Masuk ke rekening":"Bayar dari rekening"}</span><button type="button" class="link" data-act="newAccInline">+ Baru</button></div><select class="inp" id="fAcc" name="acc">${accOptions(t.acc)}</select></div>
    <div class="row2"><div><div class="lbl">Tanggal</div><input class="inp" type="date" id="fDate" name="date" value="${esc(t.date||today())}" max="${today()}"></div>
      <div><div class="lbl">Catatan</div><input class="inp" id="fNote" name="note" maxlength="80" placeholder="mis. Warteg" value="${esc(t.note||"")}"></div></div>
    ${t.items&&t.items.length?`<div><div class="lbl">Item dari struk</div><div class="items">${t.items.map(i=>`<div><span>${esc(i.qty>1?i.qty+"× ":"")}${esc(i.name)}</span><span class="num">${rp(i.price)}</span></div>`).join("")}</div></div>`:""}
    ${t.scanned?`<p class="hint">Hasil baca otomatis. Periksa nominal, tanggal, dan rekening sebelum menyimpan.</p>`:""}`;
}
function txForm(t){
  const type = t.type||"out";
  if (t.id && t.type==="tf" && t.sv){ svTfDetail(t); return; }
  openSheet(t.id?"Ubah transaksi":(t.scanned?"Cek hasil scan":"Catat transaksi"), `<form id="txForm" class="form" novalidate>
    <input type="hidden" name="rid" value="${esc(t.id||"")}">
    <div class="seg"><label><input type="radio" name="type" value="out" ${type==="out"?"checked":""}><span>Keluar</span></label><label><input type="radio" name="type" value="in" ${type==="in"?"checked":""}><span>Masuk</span></label><label><input type="radio" name="type" value="tf" ${type==="tf"?"checked":""}><span>Transfer</span></label></div>
    <label class="amount"><span class="cur">Rp</span><input id="fAmount" name="amount" inputmode="numeric" data-money autocomplete="off" placeholder="0" value="${t.amount?fmtNum(t.amount):""}" aria-label="Nominal"></label>
    <div id="txFields" class="form">${txFields(t)}</div>
    <p class="err" id="txErr" hidden></p>
    <div class="actions ${t.id?"two":""}">${t.id?`<button type="button" class="btn danger" data-act="delTx" data-id="${esc(t.id)}" aria-label="Hapus transaksi">${ic("trash")}</button>`:""}<button class="btn block" type="submit">Simpan</button></div>
  </form>`);
  S.formItems = t.items || null; S.formScanned = !!t.scanned;
}
function readTxDraft(){
  const f = $("#txForm"); if (!f) return null; const fd = new FormData(f);
  return {id:fd.get("rid")||undefined, type:fd.get("type"), amount:parseRp(fd.get("amount")), category:fd.get("cat"), acc:fd.get("acc"), to:fd.get("to"),
    date:fd.get("date"), note:fd.get("note"), fee:parseRp(fd.get("fee")), items:S.formItems, scanned:S.formScanned};
}
function svTfDetail(t){
  openSheet("Setoran tabungan", `<div class="form"><div class="card" style="box-shadow:none;background:var(--surface2)">
    <small style="color:var(--muted)">${esc(shortDate(t.date))}</small><div style="font:800 26px var(--display)" class="num">${hid(t.amount)}</div>
    <small style="color:var(--muted)">${esc(endName(t.acc))} → ${esc(endName(t.to))}</small></div>
    <p class="hint">Transaksi ini dibuat dari menu Tabungan. Menghapusnya juga membatalkan perubahan saldo tabungan.</p>
    <button type="button" class="btn danger block" data-act="delTx" data-id="${esc(t.id)}">${ic("trash")}Hapus transaksi</button></div>`);
}
