function addMenu(){
  const row = (act, type, cls, icn, title, sub) => `<button type="button" data-act="${act}" ${type?`data-type="${type}"`:""}><span class="qi ${cls}" style="width:44px;height:44px;border-radius:14px">${ic(icn)}</span><span><b>${title}</b><small>${sub}</small></span></button>`;
  openSheet("Tambah catatan", `<div class="menu">
    ${row("newTx","out","out","outArr","Pengeluaran","Belanja, makan, tagihan, dan lainnya")}
    ${row("newTx","in","in","inArr","Pemasukan","Gaji, THR, hasil usaha")}
    ${row("newTx","tf","tf","swap","Transfer","Pindah dana antar rekening, tarik tunai")}
    ${row("scan","","scan","camera","Scan struk","Foto struk, nominal & item terisi otomatis")}
    ${row("newAcc","","scan","bank","Rekening baru","Bank, e-wallet, kartu kredit, tunai")}
    ${row("newSv","","gold","gold","Tabungan / emas","Dana darurat, emas, deposito")}
  </div>`);
  $(".fab").classList.add("open");
}
