function settingsSheet(focusGold){
  const st = settings();
  openSheet("Pengaturan", `<form id="setForm" class="form" novalidate>
    <div><div class="lbl">Anggaran pengeluaran bulanan</div><input class="inp" id="stBudget" name="budget" inputmode="numeric" data-money placeholder="Rp 0 (kosongkan jika tidak pakai)" value="${st.budget?fmtNum(st.budget):""}"></div>
    <div><div class="lbl">Harga emas per gram</div><input class="inp" id="stGold" name="goldPrice" inputmode="numeric" data-money placeholder="Rp 0" value="${st.goldPrice?fmtNum(st.goldPrice):""}"><p class="hint" style="margin-top:6px">Cek harga buyback terbaru di butik emas atau aplikasi bank, lalu perbarui di sini.</p></div>
    <button class="btn block" type="submit">Simpan pengaturan</button>
  </form>
  <div class="menu" style="margin-top:18px">
    <button type="button" data-act="catBudgets"><span class="qi out">${ic("target")}</span><span><b>Pos anggaran per kategori</b><small>Batas bulanan untuk Pendidikan, Makan, Transportasi, dll.</small></span></button>
    <button type="button" data-act="backup"><span class="qi in">${ic("download")}</span><span><b>Cadangkan data</b><small>${CAP ? "Disimpan ke folder Documents › FinancialFreedom" : "Simpan semua rekening, transaksi & tabungan ke satu file"}</small></span></button>
    ${CAP && plug("Share") ? `<button type="button" data-act="shareBackup"><span class="qi scan">${ic("arrowR")}</span><span><b>Kirim cadangan</b><small>Simpan ke Google Drive atau kirim lewat WhatsApp</small></span></button>` : ""}
    <div class="filebtn menu-file"><span class="qi tf">${ic("swap")}</span><span><b>Pulihkan data</b><small>${CAP ? "Di pemilih file: ☰ → Penyimpanan internal → Documents → FinancialFreedom" : "Muat file cadangan .json, mis. di HP baru"}</small></span><input type="file" id="restoreFile" ${CAP ? "" : 'accept="application/json,.json"'} aria-label="Pilih file cadangan"></div>
    <button type="button" data-act="export"><span class="qi scan">${ic("receipt")}</span><span><b>Unduh CSV</b><small>Semua transaksi beserta rekeningnya, bisa dibuka di Excel</small></span></button>
    ${hasDemo()?`<button type="button" data-act="clearDemo"><span class="qi gold">${ic("trash")}</span><span><b>Hapus data contoh</b><small>Catatanmu sendiri tetap aman</small></span></button>`:`<button type="button" data-act="loadDemo"><span class="qi gold">${ic("star")}</span><span><b>Isi data contoh</b><small>Lihat aplikasi dengan data 6 bulan</small></span></button>`}
  </div>
  <p class="hint" style="margin-top:16px">${S.mode==="cloud"?"Data tersimpan privat di akun Claude-mu dan tersinkron di semua perangkat. Orang lain yang membuka tautan ini tidak bisa melihatnya.":(S.storageBad ? "Penyimpanan tidak tersedia di tampilan ini, jadi data akan hilang saat ditutup." : CAP ? "Data tersimpan di HP ini. Cadangkan rutin supaya aman jika HP hilang atau diganti." : "Data tersimpan di browser ini saja. Cadangkan rutin, dan jangan hapus data situs Chrome.")}</p>
  <p class="hint app-version">Financial Freedom versi ${APP_VERSION}</p>`);
  if (focusGold) setTimeout(()=>{ const g=$("#stGold"); g&&g.focus({preventScroll:true}); },200);
}
