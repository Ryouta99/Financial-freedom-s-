function accForm(a, back){
  const type = a.type||"bank";
  openSheet(a.id?"Ubah rekening":"Rekening baru", `<form id="accForm" class="form" novalidate>
    <input type="hidden" name="rid" value="${esc(a.id||"")}"><input type="hidden" name="back" value="${back?"1":""}">
    <div><div class="lbl">Jenis</div><div class="chips">${Object.entries(ACCTYPES).map(([k,t])=>`<label style="--cc:var(${t.c})"><input type="radio" name="type" value="${k}" ${k===type?"checked":""}><span><span class="cat-ic">${ic(t.i)}</span>${t.n}</span></label>`).join("")}</div></div>
    <div><div class="lbl">Nama rekening</div><input class="inp" id="aName" name="name" maxlength="40" placeholder="mis. BCA Gaji, Dompet, GoPay" value="${esc(a.name||"")}"></div>
    <div class="row2"><div><div class="lbl">Saldo awal</div><input class="inp" id="aInit" name="init" inputmode="numeric" data-money placeholder="Rp 0" value="${a.init?fmtNum(Math.abs(a.init)):""}"></div>
      <div><div class="lbl">4 digit akhir</div><input class="inp" id="aNo" name="no" inputmode="numeric" maxlength="4" placeholder="opsional" value="${esc(a.no||"")}"></div></div>
    <p class="hint">Saldo awal adalah saldo saat mulai dicatat. Untuk kartu kredit, isi tagihan yang sudah ada; saldonya dihitung sebagai utang.</p>
    <p class="err" id="accErr" hidden></p>
    <div class="actions ${a.id?"two":""}">${a.id?`<button type="button" class="btn danger" data-act="delAcc" data-id="${esc(a.id)}" aria-label="Hapus rekening">${ic("trash")}</button>`:""}<button class="btn block" type="submit">Simpan</button></div>
  </form>`);
}
function accDetail(id){
  const a = S.docs.get(id); if (!a) return; const t = ACCTYPES[a.type]||ACCTYPES.lainnya; const b = accBalance(id);
  const list = allTx().filter(x=>touchesAcc(x,id)); const f = accFlow(id, ymOf(new Date()));
  openSheet(a.name, `<div class="form">
    <div class="card" style="box-shadow:none;background:var(--surface2)"><small style="color:var(--muted)">${esc(t.n)}${a.no?" · •••• "+esc(a.no):""}</small>
      <div style="font:800 30px var(--display);letter-spacing:-.02em" class="num ${b<0?"neg":""}">${hid(b)}</div>
      <div class="row2" style="margin-top:8px;font-size:12px;color:var(--muted)"><span>Masuk bulan ini<b style="display:block;color:var(--in)" class="num">+${hid(f.i)}</b></span><span>Keluar bulan ini<b style="display:block;color:var(--out)" class="num">−${rp(f.o)}</b></span></div>
      <small style="color:var(--muted);display:block;margin-top:8px">Saldo awal ${hid(a.init||0)} · ${list.length} transaksi</small></div>
    <div class="row2"><button type="button" class="btn ghost" data-act="newTxFrom" data-id="${esc(id)}" data-type="out">${ic("outArr")}Keluar</button><button type="button" class="btn ghost" data-act="newTxFrom" data-id="${esc(id)}" data-type="in">${ic("inArr")}Masuk</button></div>
    <div class="row2"><button type="button" class="btn ghost" data-act="newTxFrom" data-id="${esc(id)}" data-type="tf">${ic("swap")}Transfer</button><button type="button" class="btn ghost" data-act="editAcc" data-id="${esc(id)}">Ubah</button></div>
    <div><div class="lbl"><span>Jejak transaksi</span>${list.length?`<button type="button" class="link" data-act="traceAcc" data-id="${esc(id)}">Buka di Riwayat</button>`:""}</div>
    ${list.length?`<div class="tx-list">${list.slice(0,30).map(x=>txRowDated(x,id)).join("")}</div>${list.length>30?`<p class="hint">Menampilkan 30 terbaru dari ${list.length}.</p>`:""}`:`<p class="hint">Belum ada transaksi di rekening ini.</p>`}</div>
  </div>`);
}
function txRowDated(t, accId){ return txRow(t, accId).replace('<small>', `<small>${esc(shortDate(t.date))} · `); }
