/* ---------- render ---------- */
function render(){
  document.querySelectorAll(".nav [data-tab]").forEach(b => b.classList.toggle("on", b.dataset.tab===S.tab));
  const eb = $("#eyeBtn"); eb.innerHTML = ic(S.hide?"eyeOff":"eye"); eb.setAttribute("aria-pressed", S.hide?"true":"false"); eb.setAttribute("aria-label", S.hide?"Tampilkan saldo":"Sembunyikan saldo");
  document.body.classList.toggle("masked", S.hide);
  const h = new Date().getHours();
  $("#greet").textContent = h<11?"Selamat pagi":h<15?"Selamat siang":h<18?"Selamat sore":"Selamat malam";
  const v = $("#view");
  if (!S.ready){ v.innerHTML = `<div class="skel" style="height:200px"></div><div class="skel" style="height:84px;margin-top:16px"></div><div class="skel" style="height:240px;margin-top:16px"></div>`; return; }
  const anim = S.anim && !reduceMotion; S.anim = false;
  if (!anim) v.classList.remove("enter");
  v.innerHTML = ({home:viewHome, tx:viewTx, stats:viewStats, assets:viewAssets}[S.tab])();
  v.querySelectorAll(".tx-list>.tx,.list>*,.acc-strip>*,.cat-list>*").forEach((e,i,arr) => e.style.setProperty("--i", Math.min(Array.prototype.indexOf.call(e.parentNode.children, e), 12)));
  if (anim){
    v.classList.remove("enter"); void v.offsetWidth; v.classList.add("enter");
    clearTimeout(S.enterT); S.enterT = setTimeout(() => v.classList.remove("enter"), 1600);
    v.querySelectorAll("[data-count]").forEach(countUp);
  }
}
const reduceMotion = (() => { try{ return matchMedia("(prefers-reduced-motion: reduce)").matches; }catch(e){ return false; } })();
function countUp(el){
  const target = Number(el.dataset.count) || 0; if (!target || (S.hide && el.dataset.priv)) return;
  const t0 = performance.now(), dur = 900;
  const tick = now => { if (!el.isConnected) return; const k = Math.min(1,(now-t0)/dur); const e = 1-Math.pow(1-k,3);
    el.textContent = rp(target*e); if (k<1) requestAnimationFrame(tick); else el.textContent = rp(target); };
  el.textContent = rp(0); requestAnimationFrame(tick);
}
const monthBar = () => { const cur=ymOf(new Date()); return `<div class="monthbar">
  <button type="button" data-act="prevMonth" aria-label="Bulan sebelumnya">${ic("chevL")}</button>
  <span class="m">${monthName(S.month)}</span>
  <button type="button" data-act="nextMonth" aria-label="Bulan berikutnya" ${S.month>=cur?"disabled":""}>${ic("chevR")}</button></div>`; };
const demoBanner = () => hasDemo() ? `<div class="demo-banner">${ic("star")}<span>Ini <b>data contoh</b> untuk melihat cara kerja aplikasi.</span><button type="button" data-act="clearDemo">Hapus contoh</button></div>` : "";
