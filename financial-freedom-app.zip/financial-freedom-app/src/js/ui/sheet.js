/* ---------- sheet ---------- */
function openSheet(title, html){
  $("#sheetBody").innerHTML = `<div class="panel-h"><h3 id="sheetTitle">${esc(title)}</h3><button type="button" class="close" data-act="close" aria-label="Tutup">${ic("x")}</button></div>${html}`;
  const sh = $("#sheet"); clearTimeout(S.closeT); sh.classList.remove("closing"); sh.classList.add("open"); sh.setAttribute("aria-hidden","false");
  $(".fab").classList.remove("open");
  $(".panel").scrollTop = 0; S.sheetOpenAt = Date.now();
}
function closeSheet(){
  const sh=$("#sheet"); S.scanFile=null; $(".fab").classList.remove("open");
  if (!sh.classList.contains("open")) return;
  sh.setAttribute("aria-hidden","true"); sh.classList.add("closing"); clearTimeout(S.closeT);
  S.closeT = setTimeout(() => sh.classList.remove("open","closing"), reduceMotion ? 0 : 190);
}
let tT; function toast(msg){ const t=$("#toast"); t.textContent=msg; t.classList.add("show"); clearTimeout(tT); tT=setTimeout(()=>t.classList.remove("show"),2600); }
